package com.example.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {

    private const val CHANNEL_LESSONS_ID = "em_lessons_channel"
    private const val CHANNEL_POMODORO_ID = "em_pomodoro_channel"
    const val CHANNEL_STUDY_REMINDERS_ID = "em_study_reminders_channel"

    fun initNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val studyRemindersChannel = NotificationChannel(
                CHANNEL_STUDY_REMINDERS_ID,
                "تذكيرات جلسات الدراسة والمذاكرة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات هادئة ولطيفة لتذكيرك بمواعيد جلسات المذاكرة والدروس القادمة"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 150, 200)
            }

            val lessonChannel = NotificationChannel(
                CHANNEL_LESSONS_ID,
                "تنبيهات الدروس والمحاضرات",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات تذكيرية قبل موعد الحصص والدروس"
                enableVibration(true)
            }

            val pomodoroChannel = NotificationChannel(
                CHANNEL_POMODORO_ID,
                "مؤقت الدراسة (بومودورو)",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات انتهاء وقت التركيز وفترات الراحة"
            }

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(studyRemindersChannel)
            manager.createNotificationChannel(lessonChannel)
            manager.createNotificationChannel(pomodoroChannel)
        }
    }

    fun showGentleStudyReminder(
        context: Context,
        lessonTitle: String,
        subject: String,
        startTime: String,
        location: String,
        minutesBefore: Int,
        notificationId: Int = 1001
    ) {
        try {
            val appIntent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("navigate_to", "study")
            }

            val pendingIntent = android.app.PendingIntent.getActivity(
                context,
                notificationId,
                appIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )

            val locationSuffix = if (location.isNotBlank()) " في $location" else ""
            val messageContent = "تبدأ جلسة $lessonTitle ($subject) خلال $minutesBefore دقيقة (الساعة $startTime)$locationSuffix.\nجهّز أدواتك واجلس في بيئة هادئة، وبالتوفيق والنجاح!"

            val builder = NotificationCompat.Builder(context, CHANNEL_STUDY_REMINDERS_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("تذكير بموعد المذاكرة: $lessonTitle 📚")
                .setContentText("تبدأ الجلسة خلال $minutesBefore دقيقة (الساعة $startTime)")
                .setStyle(NotificationCompat.BigTextStyle().bigText(messageContent))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .addAction(
                    android.R.drawable.ic_media_play,
                    "فتح جلسة المذاكرة ⏱️",
                    pendingIntent
                )

            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // Permission not granted
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun showLessonNotification(context: Context, lessonTitle: String, timeText: String) {
        try {
            val builder = NotificationCompat.Builder(context, CHANNEL_LESSONS_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("تذكير بالدرس: $lessonTitle")
                .setContentText("موعد الدرس سيبدأ قريباً في $timeText. استعد وتوكل على الله!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify((System.currentTimeMillis() % 10000).toInt(), builder.build())
        } catch (e: SecurityException) {
            // Permission not granted yet
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun showPomodoroCompleteNotification(context: Context, isFocusSession: Boolean) {
        try {
            val title = if (isFocusSession) "أحسنت! انتهت جلسة التركيز 🎉" else "انتهت فترة الراحة ⏰"
            val message = if (isFocusSession) "حان وقت استراحة قصيرة مدتها 5 دقائق لإنعاش عقلك." else "جاهز لبدء جولة دراسية جديدة؟ هيا نستمر في التقدم!"

            val builder = NotificationCompat.Builder(context, CHANNEL_POMODORO_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)

            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(999, builder.build())
        } catch (e: SecurityException) {
            // Handled
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
