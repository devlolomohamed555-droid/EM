package com.example.ui.viewmodels

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LessonEntity
import com.example.data.local.PrayerRecordEntity
import com.example.data.local.UserEntity
import com.example.data.model.*
import com.example.data.repository.AppRepository
import com.example.data.repository.EducationalData
import com.example.utils.AudioPlayerHelper
import com.example.utils.NotificationHelper
import com.example.utils.TimeUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)

    // User Profile
    val userProfile: StateFlow<UserEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Lessons
    val allLessons: StateFlow<List<LessonEntity>> = repository.allLessons
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Prayer Records
    val todayPrayerRecord: StateFlow<PrayerRecordEntity?> = repository.getTodayPrayerRecord()
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Prayer Timings
    private val _prayerTiming = MutableStateFlow(PrayerTiming())
    val prayerTiming: StateFlow<PrayerTiming> = _prayerTiming

    private val _nextPrayer = MutableStateFlow<NextPrayerInfo?>(null)
    val nextPrayer: StateFlow<NextPrayerInfo?> = _nextPrayer

    private val _nextLesson = MutableStateFlow<Pair<LessonEntity?, Long>>(Pair(null, -1L))
    val nextLesson: StateFlow<Pair<LessonEntity?, Long>> = _nextLesson

    // Motivational Quote (changes every 5 minutes)
    private val _currentQuoteIndex = MutableStateFlow(0)
    val currentQuote: StateFlow<MotivationalQuote> = _currentQuoteIndex.map { index ->
        val quotes = EducationalData.motivationalQuotes
        quotes[index % quotes.size]
    }.stateIn(viewModelScope, SharingStarted.Eagerly, EducationalData.motivationalQuotes.first())

    // Dynamic Zikr
    private val _currentZikrIndex = MutableStateFlow(0)
    val currentZikr: StateFlow<DailyZikr> = _currentZikrIndex.map { index ->
        val zikrs = EducationalData.dailyAzkarList
        zikrs[index % zikrs.size]
    }.stateIn(viewModelScope, SharingStarted.Eagerly, EducationalData.dailyAzkarList.first())

    private val _zikrCount = MutableStateFlow(0)
    val zikrCount: StateFlow<Int> = _zikrCount

    // Pomodoro Timer State
    private val _pomodoroSecondsRemaining = MutableStateFlow(25 * 60)
    val pomodoroSecondsRemaining: StateFlow<Int> = _pomodoroSecondsRemaining

    private val _isPomodoroRunning = MutableStateFlow(false)
    val isPomodoroRunning: StateFlow<Boolean> = _isPomodoroRunning

    private val _isFocusPhase = MutableStateFlow(true) // true: focus, false: break
    val isFocusPhase: StateFlow<Boolean> = _isFocusPhase

    private val _pomodoroAmbianceIndex = MutableStateFlow(0)
    val pomodoroAmbianceIndex: StateFlow<Int> = _pomodoroAmbianceIndex

    private var pomodoroJob: Job? = null

    // Surahs & Quran
    private val _surahs = MutableStateFlow<List<Surah>>(emptyList())
    val surahs: StateFlow<List<Surah>> = _surahs

    private val _selectedSurahDetail = MutableStateFlow<Pair<Surah, List<Ayah>>?>(null)
    val selectedSurahDetail: StateFlow<Pair<Surah, List<Ayah>>?> = _selectedSurahDetail

    private val _isLoadingQuran = MutableStateFlow(false)
    val isLoadingQuran: StateFlow<Boolean> = _isLoadingQuran

    // Audio Playback State from AudioPlayerHelper
    val audioIsPlaying: StateFlow<Boolean> = AudioPlayerHelper.isPlaying
    val audioIsLoading: StateFlow<Boolean> = AudioPlayerHelper.isLoading
    val audioCurrentTitle: StateFlow<String> = AudioPlayerHelper.currentTitle
    val audioCurrentSurahNumber: StateFlow<Int?> = AudioPlayerHelper.currentSurahNumber
    val audioCurrentPositionMs: StateFlow<Int> = AudioPlayerHelper.currentPositionMs
    val audioDurationMs: StateFlow<Int> = AudioPlayerHelper.durationMs
    val selectedReciter: StateFlow<QuranReciter> = AudioPlayerHelper.selectedReciter
    val defaultReciters: List<QuranReciter> = AudioPlayerHelper.defaultReciters

    // Visual Analytics & Statistics Data
    val recentPomodoros: StateFlow<List<com.example.data.local.PomodoroRecordEntity>> = repository.recentPomodoros
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentPrayers: StateFlow<List<com.example.data.local.PrayerRecordEntity>> = repository.recentPrayers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        NotificationHelper.initNotificationChannels(application)
        viewModelScope.launch {
            val user = repository.ensureInitialUser()
            _pomodoroAmbianceIndex.value = user.pomodoroBackgroundTheme
            _pomodoroSecondsRemaining.value = user.pomodoroFocusMinutes * 60
            repository.ensureWeeklyStatsBaseline()
        }
        viewModelScope.launch {
            allLessons.collect { lessons ->
                if (lessons.isNotEmpty()) {
                    com.example.utils.StudyReminderScheduler.rescheduleAllLessons(getApplication(), lessons)
                }
            }
        }
        loadPrayerTimes()
        loadQuranSurahs()
        startClockAndTicker()
    }

    private fun loadPrayerTimes(lat: Double = 30.0444, lng: Double = 31.2357) {
        viewModelScope.launch {
            try {
                val timings = repository.getPrayerTimes(lat, lng)
                _prayerTiming.value = timings
                _nextPrayer.value = TimeUtils.calculateNextPrayer(timings)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateLocation(lat: Double, lng: Double) {
        loadPrayerTimes(lat, lng)
    }

    private fun loadQuranSurahs() {
        viewModelScope.launch {
            _isLoadingQuran.value = true
            try {
                _surahs.value = repository.getSurahs()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoadingQuran.value = false
            }
        }
    }

    fun openSurah(surahNumber: Int) {
        viewModelScope.launch {
            _isLoadingQuran.value = true
            try {
                val detail = repository.getSurahDetail(surahNumber)
                _selectedSurahDetail.value = detail
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                _isLoadingQuran.value = false
            }
        }
    }

    fun playAyahAudio(audioUrl: String, ayahLabel: String = "آية كريمة") {
        AudioPlayerHelper.playAudio(audioUrl, ayahLabel)
    }

    fun playSurahAudio(surahNumber: Int, surahName: String) {
        AudioPlayerHelper.playSurah(surahNumber, surahName)
    }

    fun toggleAudioPlayPause() {
        AudioPlayerHelper.togglePlayPause()
    }

    fun seekAudio(positionMs: Int) {
        AudioPlayerHelper.seekTo(positionMs)
    }

    fun forwardAudio() {
        AudioPlayerHelper.forward10Seconds()
    }

    fun rewindAudio() {
        AudioPlayerHelper.rewind10Seconds()
    }

    fun setReciter(reciter: QuranReciter) {
        AudioPlayerHelper.setReciter(reciter)
    }

    fun stopAudio() {
        AudioPlayerHelper.stopAudio()
    }

    // Ticker that runs every second to update countdowns and quotes every 5 minutes
    private fun startClockAndTicker() {
        viewModelScope.launch {
            var secondCounter = 0
            while (true) {
                delay(1000L)
                secondCounter++

                // Update Next Prayer countdown
                val timings = _prayerTiming.value
                _nextPrayer.value = TimeUtils.calculateNextPrayer(timings)

                // Update Next Lesson countdown
                val lessons = allLessons.value
                _nextLesson.value = TimeUtils.calculateNextLesson(lessons)

                // Every 5 minutes (300 seconds), rotate motivational quote
                if (secondCounter % 300 == 0) {
                    rotateQuote()
                }
            }
        }
    }

    fun rotateQuote() {
        _currentQuoteIndex.value = (_currentQuoteIndex.value + 1) % EducationalData.motivationalQuotes.size
    }

    fun nextZikr() {
        _currentZikrIndex.value = (_currentZikrIndex.value + 1) % EducationalData.dailyAzkarList.size
        _zikrCount.value = 0
    }

    fun incrementZikr() {
        val target = currentZikr.value.targetCount
        if (_zikrCount.value < target) {
            _zikrCount.value = _zikrCount.value + 1
        } else {
            nextZikr()
        }
    }

    // Pomodoro Controls
    fun startPomodoro() {
        if (_isPomodoroRunning.value) return
        _isPomodoroRunning.value = true
        pomodoroJob?.cancel()
        pomodoroJob = viewModelScope.launch {
            while (_isPomodoroRunning.value && _pomodoroSecondsRemaining.value > 0) {
                delay(1000L)
                _pomodoroSecondsRemaining.value -= 1
            }
            if (_pomodoroSecondsRemaining.value <= 0) {
                // Phase completed
                val wasFocus = _isFocusPhase.value
                NotificationHelper.showPomodoroCompleteNotification(getApplication(), wasFocus)

                val user = userProfile.value
                val focusMins = user?.pomodoroFocusMinutes ?: 25
                val breakMins = user?.pomodoroBreakMinutes ?: 5

                if (wasFocus) {
                    viewModelScope.launch {
                        repository.recordPomodoroSession(focusMins)
                    }
                    _isFocusPhase.value = false
                    _pomodoroSecondsRemaining.value = breakMins * 60
                } else {
                    _isFocusPhase.value = true
                    _pomodoroSecondsRemaining.value = focusMins * 60
                }
                _isPomodoroRunning.value = false
            }
        }
    }

    fun recordManualFocusMinutes(minutes: Int) {
        viewModelScope.launch {
            repository.recordPomodoroSession(minutes)
        }
    }

    fun pausePomodoro() {
        _isPomodoroRunning.value = false
        pomodoroJob?.cancel()
    }

    fun resetPomodoro() {
        _isPomodoroRunning.value = false
        pomodoroJob?.cancel()
        val user = userProfile.value
        val focusMins = user?.pomodoroFocusMinutes ?: 25
        _isFocusPhase.value = true
        _pomodoroSecondsRemaining.value = focusMins * 60
    }

    fun setPomodoroCustomMinutes(focus: Int, breakTime: Int) {
        viewModelScope.launch {
            repository.updatePomodoroTimes(focus, breakTime)
            if (!_isPomodoroRunning.value) {
                _isFocusPhase.value = true
                _pomodoroSecondsRemaining.value = focus * 60
            }
        }
    }

    fun setAmbianceTheme(themeIndex: Int) {
        _pomodoroAmbianceIndex.value = themeIndex
        viewModelScope.launch {
            repository.updatePomodoroBackgroundTheme(themeIndex)
        }
    }

    // User Profile Actions
    fun toggleGenderTheme(theme: String) {
        viewModelScope.launch {
            repository.updateGenderTheme(theme)
        }
    }

    fun updateGradeAndStream(gradeId: String, streamId: String) {
        viewModelScope.launch {
            repository.updateGradeAndStream(gradeId, streamId)
        }
    }

    fun saveUserNameAndEmail(name: String, email: String, isGuest: Boolean) {
        viewModelScope.launch {
            val current = userProfile.value ?: UserEntity()
            repository.saveUserProfile(current.copy(name = name, email = email, isGuest = isGuest))
        }
    }

    // Daily Prayer Tracker
    fun togglePrayer(prayerName: String, done: Boolean) {
        viewModelScope.launch {
            repository.togglePrayer(prayerName, done)
        }
    }

    // Schedule Lessons Actions & Gentle Study Reminders
    fun addLesson(
        title: String,
        subject: String,
        teacher: String,
        dayOfWeek: Int,
        startTime: String,
        endTime: String,
        room: String,
        reminderMinutes: Int
    ) {
        viewModelScope.launch {
            val entity = LessonEntity(
                title = title,
                subject = subject,
                teacher = teacher,
                dayOfWeek = dayOfWeek,
                startTime = startTime,
                endTime = endTime,
                locationOrRoom = room,
                reminderMinutesBefore = reminderMinutes,
                isEnabled = true
            )
            val newId = repository.insertLesson(entity)
            com.example.utils.StudyReminderScheduler.scheduleLessonReminder(
                getApplication(),
                entity.copy(id = newId)
            )
        }
    }

    fun deleteLesson(id: Long) {
        viewModelScope.launch {
            com.example.utils.StudyReminderScheduler.cancelLessonReminder(getApplication(), id)
            repository.deleteLesson(id)
        }
    }

    fun toggleLessonEnabled(lesson: LessonEntity) {
        viewModelScope.launch {
            val updated = lesson.copy(isEnabled = !lesson.isEnabled)
            repository.insertLesson(updated)
            if (updated.isEnabled) {
                com.example.utils.StudyReminderScheduler.scheduleLessonReminder(getApplication(), updated)
            } else {
                com.example.utils.StudyReminderScheduler.cancelLessonReminder(getApplication(), updated.id)
            }
        }
    }

    fun sendTestNotification(title: String, time: String) {
        NotificationHelper.showLessonNotification(getApplication(), title, time)
    }

    fun sendGentleStudyReminderTest(
        lessonTitle: String = "مراجعة الرياضيات والفيزياء",
        subject: String = "الرياضيات",
        timeText: String = "05:00 م"
    ) {
        NotificationHelper.showGentleStudyReminder(
            context = getApplication(),
            lessonTitle = lessonTitle,
            subject = subject,
            startTime = timeText,
            location = "غرفة المذاكرة",
            minutesBefore = 15
        )
    }
}
