package com.example.utils

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.local.LessonEntity
import com.example.receiver.StudyReminderReceiver
import java.util.Calendar

object StudyReminderScheduler {

    private const val TAG = "StudyReminderScheduler"

    /**
     * Calculates the exact next trigger time in epoch milliseconds for a study session.
     * Subtracts [minutesBefore] from the session start time.
     * If the target time for this week's day has already passed, schedules for the upcoming week.
     */
    fun calculateNextTriggerMillis(dayOfWeek: Int, startTime: String, minutesBefore: Int = 15): Long {
        val now = Calendar.getInstance()
        val nowMillis = now.timeInMillis

        val parts = startTime.split(":")
        val startHour = parts.getOrNull(0)?.toIntOrNull() ?: 9
        val startMinute = parts.getOrNull(1)?.toIntOrNull() ?: 0

        val target = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, dayOfWeek)
            set(Calendar.HOUR_OF_DAY, startHour)
            set(Calendar.MINUTE, startMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            // Subtract gentle reminder buffer (e.g. 15 minutes before)
            add(Calendar.MINUTE, -minutesBefore)
        }

        // If this week's slot has already passed, move to next week
        if (target.timeInMillis <= nowMillis) {
            target.add(Calendar.WEEK_OF_YEAR, 1)
        }

        return target.timeInMillis
    }

    /**
     * Schedules a gentle push reminder for a single lesson or study session.
     */
    fun scheduleLessonReminder(context: Context, lesson: LessonEntity) {
        if (!lesson.isEnabled) {
            cancelLessonReminder(context, lesson.id)
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val triggerMillis = calculateNextTriggerMillis(
            dayOfWeek = lesson.dayOfWeek,
            startTime = lesson.startTime,
            minutesBefore = lesson.reminderMinutesBefore
        )

        val intent = Intent(context, StudyReminderReceiver::class.java).apply {
            action = StudyReminderReceiver.ACTION_STUDY_REMINDER
            putExtra(StudyReminderReceiver.EXTRA_LESSON_ID, lesson.id)
            putExtra(StudyReminderReceiver.EXTRA_LESSON_TITLE, lesson.title)
            putExtra(StudyReminderReceiver.EXTRA_LESSON_SUBJECT, lesson.subject)
            putExtra(StudyReminderReceiver.EXTRA_LESSON_START_TIME, lesson.startTime)
            putExtra(StudyReminderReceiver.EXTRA_LESSON_LOCATION, lesson.locationOrRoom)
            putExtra(StudyReminderReceiver.EXTRA_LESSON_DAY_OF_WEEK, lesson.dayOfWeek)
            putExtra(StudyReminderReceiver.EXTRA_REMINDER_MINUTES, lesson.reminderMinutesBefore)
        }

        val requestCode = (lesson.id % 100000).toInt()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            }
            Log.d(TAG, "Scheduled reminder for '${lesson.title}' at millis: $triggerMillis")
        } catch (e: SecurityException) {
            Log.w(TAG, "SecurityException scheduling exact alarm: ${e.message}")
            try {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Cancels an existing scheduled reminder for a lesson.
     */
    fun cancelLessonReminder(context: Context, lessonId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, StudyReminderReceiver::class.java).apply {
            action = StudyReminderReceiver.ACTION_STUDY_REMINDER
        }
        val requestCode = (lessonId % 100000).toInt()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
            Log.d(TAG, "Cancelled reminder for lessonId: $lessonId")
        }
    }

    /**
     * Reschedules all enabled lessons in the database.
     */
    fun rescheduleAllLessons(context: Context, lessons: List<LessonEntity>) {
        lessons.forEach { lesson ->
            if (lesson.isEnabled) {
                scheduleLessonReminder(context, lesson)
            } else {
                cancelLessonReminder(context, lesson.id)
            }
        }
    }
}
