package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ProfileDrawerContent
import com.example.ui.screens.*
import com.example.ui.theme.EmStudentTheme
import com.example.ui.viewmodels.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
            val genderTheme = userProfile?.genderTheme ?: "boy"

            var isAuthenticated by remember { mutableStateOf(false) }

            // Check if user has initialized
            LaunchedEffect(userProfile) {
                if (userProfile != null && userProfile!!.gradeId.isNotBlank()) {
                    isAuthenticated = true
                }
            }

            EmStudentTheme(genderTheme = genderTheme) {
                // Arabic RTL Layout direction for the whole app
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    if (!isAuthenticated) {
                        AuthScreen(
                            viewModel = viewModel,
                            onLoginSuccess = { isAuthenticated = true }
                        )
                    } else {
                        MainAppContent(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var currentScreen by remember { mutableStateOf("home") }
    var islamicInitialTab by remember { mutableIntStateOf(0) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ProfileDrawerContent(
                viewModel = viewModel,
                onNavigate = { route ->
                    when (route) {
                        "study" -> currentScreen = "study"
                        "schedule" -> currentScreen = "schedule"
                        "islamic_prayers" -> {
                            islamicInitialTab = 1
                            currentScreen = "islamic"
                        }
                        "islamic_quran" -> {
                            islamicInitialTab = 0
                            currentScreen = "islamic"
                        }
                        "adhkar_morning", "adhkar_evening", "adhkar_sleep", "adhkar_study" -> {
                            islamicInitialTab = 2
                            currentScreen = "islamic"
                        }
                        "library" -> currentScreen = "library"
                        else -> currentScreen = "home"
                    }
                },
                onClose = {
                    scope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = when (currentScreen) {
                                "study" -> "جلسة الدراسة (بومودورو)"
                                "schedule" -> "مواعيد دروسي"
                                "islamic" -> "إسلاميات وقرآن"
                                "library" -> "المكتبة والمناهج"
                                else -> "القائمة الرئيسية"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                scope.launch {
                                    if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                }
                            },
                            modifier = Modifier.testTag("drawer_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "القائمة"
                            )
                        }
                    },
                    actions = {
                        // "R" profile avatar button as seen on Page 3 screenshot
                        IconButton(
                            onClick = {
                                scope.launch { drawerState.open() }
                            },
                            modifier = Modifier.testTag("profile_avatar_button")
                        ) {
                            Surface(
                                modifier = Modifier.size(34.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "R",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentScreen == "home",
                        onClick = { currentScreen = "home" },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "home") Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "الرئيسية"
                            )
                        },
                        label = { Text("الرئيسية", fontSize = 11.sp) }
                    )

                    NavigationBarItem(
                        selected = currentScreen == "study",
                        onClick = { currentScreen = "study" },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "study") Icons.Filled.HourglassBottom else Icons.Outlined.HourglassBottom,
                                contentDescription = "المذاكرة"
                            )
                        },
                        label = { Text("المذاكرة", fontSize = 11.sp) }
                    )

                    NavigationBarItem(
                        selected = currentScreen == "schedule",
                        onClick = { currentScreen = "schedule" },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "schedule") Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth,
                                contentDescription = "دروسي"
                            )
                        },
                        label = { Text("دروسي", fontSize = 11.sp) }
                    )

                    NavigationBarItem(
                        selected = currentScreen == "islamic",
                        onClick = {
                            islamicInitialTab = 0
                            currentScreen = "islamic"
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "islamic") Icons.Filled.Mosque else Icons.Outlined.Mosque,
                                contentDescription = "إسلاميات"
                            )
                        },
                        label = { Text("إسلاميات", fontSize = 11.sp) }
                    )

                    NavigationBarItem(
                        selected = currentScreen == "library",
                        onClick = { currentScreen = "library" },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == "library") Icons.Filled.LibraryBooks else Icons.Outlined.LibraryBooks,
                                contentDescription = "المكتبة"
                            )
                        },
                        label = { Text("المكتبة", fontSize = 11.sp) }
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentScreen) {
                    "home" -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToStudy = { currentScreen = "study" },
                        onNavigateToSchedule = { currentScreen = "schedule" },
                        onNavigateToIslamic = {
                            islamicInitialTab = 1
                            currentScreen = "islamic"
                        },
                        onNavigateToLibrary = { currentScreen = "library" },
                        onOpenDrawer = {
                            scope.launch { drawerState.open() }
                        }
                    )

                    "study" -> PomodoroStudyScreen(
                        viewModel = viewModel,
                        onNavigateToSchedule = { currentScreen = "schedule" }
                    )

                    "schedule" -> ScheduleScreen(
                        viewModel = viewModel
                    )

                    "islamic" -> IslamicScreen(
                        viewModel = viewModel,
                        initialTab = islamicInitialTab
                    )

                    "library" -> LibraryScreen(
                        viewModel = viewModel,
                        onChangeGradeRequested = {
                            scope.launch { drawerState.open() }
                        }
                    )
                }
            }
        }
    }
}
