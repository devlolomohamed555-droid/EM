package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 1. Boy Color Scheme (Deep Navy & Slate Teal - Low Eye Strain)
private val BoyLightColorScheme = lightColorScheme(
    primary = BoyNavyPrimary,
    onPrimary = BoyNavyOnPrimary,
    primaryContainer = BoyNavyPrimaryContainer,
    onPrimaryContainer = BoyNavyOnPrimaryContainer,
    secondary = BoyNavySecondary,
    onSecondary = Color.White,
    secondaryContainer = BoyNavySecondaryContainer,
    background = BoyNavyBackground,
    surface = BoyNavySurface,
    surfaceVariant = BoyNavySurfaceVariant,
    outline = BoyNavyOutline
)

private val BoyDarkColorScheme = darkColorScheme(
    primary = BoyDarkPrimary,
    onPrimary = Color(0xFF0F1722),
    primaryContainer = Color(0xFF1E3450),
    onPrimaryContainer = Color(0xFFDCE8F5),
    secondary = BoyDarkSecondary,
    onSecondary = Color(0xFF0F1722),
    background = BoyDarkBackground,
    surface = BoyDarkSurface,
    surfaceVariant = BoyDarkSurfaceVariant,
    onSurface = BoyDarkOnSurface
)

// 2. Girl Color Scheme (Warm Dusty Rose & Soft Heather - Eye-Gentle)
private val GirlLightColorScheme = lightColorScheme(
    primary = GirlPinkPrimary,
    onPrimary = GirlPinkOnPrimary,
    primaryContainer = GirlPinkPrimaryContainer,
    onPrimaryContainer = GirlPinkOnPrimaryContainer,
    secondary = GirlPinkSecondary,
    onSecondary = Color.White,
    secondaryContainer = GirlPinkSecondaryContainer,
    background = GirlPinkBackground,
    surface = GirlPinkSurface,
    surfaceVariant = GirlPinkSurfaceVariant,
    outline = GirlPinkOutline
)

private val GirlDarkColorScheme = darkColorScheme(
    primary = GirlDarkPrimary,
    onPrimary = Color(0xFF1A1117),
    primaryContainer = Color(0xFF4E2333),
    onPrimaryContainer = Color(0xFFF7E2EB),
    secondary = GirlDarkSecondary,
    onSecondary = Color(0xFF1A1117),
    background = GirlDarkBackground,
    surface = GirlDarkSurface,
    surfaceVariant = GirlDarkSurfaceVariant,
    onSurface = GirlDarkOnSurface
)

// 3. Eye-Comfort Sepia Paper Color Scheme (Medical & Optometry Study Grade)
private val EyeComfortLightColorScheme = lightColorScheme(
    primary = SepiaPrimary,
    onPrimary = SepiaOnPrimary,
    primaryContainer = SepiaPrimaryContainer,
    onPrimaryContainer = SepiaOnPrimaryContainer,
    secondary = SepiaSecondary,
    onSecondary = Color.White,
    secondaryContainer = SepiaSecondaryContainer,
    background = SepiaBackground,
    surface = SepiaSurface,
    surfaceVariant = SepiaSurfaceVariant,
    outline = SepiaOutline
)

private val EyeComfortDarkColorScheme = darkColorScheme(
    primary = SepiaDarkPrimary,
    onPrimary = Color(0xFF171411),
    primaryContainer = Color(0xFF38281A),
    onPrimaryContainer = Color(0xFFEFE3D5),
    secondary = SepiaDarkSecondary,
    onSecondary = Color(0xFF171411),
    background = SepiaDarkBackground,
    surface = SepiaDarkSurface,
    surfaceVariant = SepiaDarkSurfaceVariant,
    onSurface = SepiaDarkOnSurface
)

@Composable
fun EmStudentTheme(
    genderTheme: String = "boy", // "boy", "girl", or "eye_comfort"
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = when (genderTheme.lowercase()) {
        "girl" -> if (darkTheme) GirlDarkColorScheme else GirlLightColorScheme
        "eye_comfort", "sepia" -> if (darkTheme) EyeComfortDarkColorScheme else EyeComfortLightColorScheme
        else -> if (darkTheme) BoyDarkColorScheme else BoyLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
