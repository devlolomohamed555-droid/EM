package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.EducationalData
import com.example.ui.viewmodels.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileDrawerContent(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit,
    onClose: () -> Unit
) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val currentGender = userProfile?.genderTheme ?: "boy"
    val currentGradeId = userProfile?.gradeId ?: "bac_2"
    val currentStreamId = userProfile?.streamId ?: "bac_2_pc"

    var showGradePicker by remember { mutableStateOf(false) }

    val grade = EducationalData.grades.find { it.id == currentGradeId }
    val stream = grade?.streams?.find { it.id == currentStreamId }

    ModalDrawerSheet(
        modifier = Modifier
            .width(320.dp)
            .fillMaxHeight(),
        drawerContainerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(46.dp),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "EM",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "القائمة الرئيسية",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = userProfile?.name ?: "طالب متميز",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق القائمة")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))

            // 1. Theme Choice (مظهر التطبيق المريح للعين)
            Text(
                text = "1/ مظهر التطبيق المريح للعين:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = currentGender == "boy",
                        onClick = { viewModel.toggleGenderTheme("boy") },
                        label = { Text("أزرق كحلي هادئ", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        leadingIcon = if (currentGender == "boy") {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null
                    )

                    FilterChip(
                        selected = currentGender == "girl",
                        onClick = { viewModel.toggleGenderTheme("girl") },
                        label = { Text("وردي دافئ ناعم", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        leadingIcon = if (currentGender == "girl") {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null
                    )
                }

                FilterChip(
                    selected = currentGender == "eye_comfort" || currentGender == "sepia",
                    onClick = { viewModel.toggleGenderTheme("eye_comfort") },
                    label = { Text("وضع راحة العين (ورق سيبيا دافئ للقراءة)", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = if (currentGender == "eye_comfort" || currentGender == "sepia") {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Grade & Stream Choice (Page 2: "2/ قسم اختيار السنة الدراسية")
            Text(
                text = "2/ السنة الدراسية والشعبة:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showGradePicker = true },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = grade?.name ?: "اختر المرحلة الدراسية",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (stream != null) {
                            Text(
                                text = stream.name,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "تغيير",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(10.dp))

            // Menu Items List (Numbered as in PDF Page 2!)
            DrawerMenuItem(
                number = "3",
                title = "صفحة جلسة الدراسة (Pomodoro)",
                icon = Icons.Default.Timer,
                onClick = {
                    onNavigate("study")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "4",
                title = "مواعيد دروسي ومحاضراتي",
                icon = Icons.Default.CalendarMonth,
                onClick = {
                    onNavigate("schedule")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "5",
                title = "مواعيد الصلاة ومتابعة الفروض",
                icon = Icons.Default.AccessTime,
                onClick = {
                    onNavigate("islamic_prayers")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "6",
                title = "القرآن الكريم",
                icon = Icons.Default.AutoStories,
                onClick = {
                    onNavigate("islamic_quran")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "7",
                title = "أذكار الصباح",
                icon = Icons.Default.WbSunny,
                onClick = {
                    onNavigate("adhkar_morning")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "8",
                title = "أذكار المساء",
                icon = Icons.Default.NightsStay,
                onClick = {
                    onNavigate("adhkar_evening")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "9",
                title = "أذكار النوم",
                icon = Icons.Default.Bedtime,
                onClick = {
                    onNavigate("adhkar_sleep")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "10",
                title = "أذكار المذاكرة وأدعية النجاح",
                icon = Icons.Default.MenuBook,
                onClick = {
                    onNavigate("adhkar_study")
                    onClose()
                }
            )

            DrawerMenuItem(
                number = "11",
                title = "المكتبة والمناهج الدراسية (PDF وفيديو)",
                icon = Icons.Default.LibraryBooks,
                onClick = {
                    onNavigate("library")
                    onClose()
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Grade and Stream Picker Dialog
    if (showGradePicker) {
        var tempGradeId by remember { mutableStateOf(currentGradeId) }
        var tempStreamId by remember { mutableStateOf(currentStreamId) }

        val activeGrade = EducationalData.grades.find { it.id == tempGradeId } ?: EducationalData.grades.first()

        AlertDialog(
            onDismissRequest = { showGradePicker = false },
            title = { Text("اختر سنتك الدراسية وشعبتك", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EducationalData.grades.forEach { g ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    tempGradeId = g.id
                                    tempStreamId = g.streams.firstOrNull()?.id ?: ""
                                }
                                .background(
                                    if (tempGradeId == g.id) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                    else Color.Transparent
                                )
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = tempGradeId == g.id,
                                onClick = {
                                    tempGradeId = g.id
                                    tempStreamId = g.streams.firstOrNull()?.id ?: ""
                                }
                            )
                            Text(g.name, fontSize = 13.sp, fontWeight = if (tempGradeId == g.id) FontWeight.Bold else FontWeight.Normal)
                        }
                    }

                    if (activeGrade.streams.size > 1) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("الشعبة / المسار:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        activeGrade.streams.forEach { s ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { tempStreamId = s.id }
                                    .background(
                                        if (tempStreamId == s.id) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                                        else Color.Transparent
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = tempStreamId == s.id,
                                    onClick = { tempStreamId = s.id }
                                )
                                Text(s.name, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateGradeAndStream(tempGradeId, tempStreamId)
                        showGradePicker = false
                    }
                ) {
                    Text("حفظ التغيير")
                }
            },
            dismissButton = {
                TextButton(onClick = { showGradePicker = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun DrawerMenuItem(
    number: String,
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(28.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = number,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}
