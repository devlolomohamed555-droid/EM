package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfile(): Flow<UserEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1")
    suspend fun getUserProfileOnce(): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(user: UserEntity)

    @Query("UPDATE user_profile SET genderTheme = :theme WHERE id = 1")
    suspend fun updateGenderTheme(theme: String)

    @Query("UPDATE user_profile SET gradeId = :gradeId, streamId = :streamId WHERE id = 1")
    suspend fun updateGradeAndStream(gradeId: String, streamId: String)

    @Query("UPDATE user_profile SET pomodoroFocusMinutes = :focus, pomodoroBreakMinutes = :breakTime WHERE id = 1")
    suspend fun updatePomodoroTimes(focus: Int, breakTime: Int)

    @Query("UPDATE user_profile SET pomodoroBackgroundTheme = :themeIndex WHERE id = 1")
    suspend fun updatePomodoroBackgroundTheme(themeIndex: Int)
}

@Dao
interface LessonDao {
    @Query("SELECT * FROM lessons ORDER BY dayOfWeek ASC, startTime ASC")
    fun getAllLessons(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons WHERE dayOfWeek = :dayOfWeek ORDER BY startTime ASC")
    fun getLessonsByDay(dayOfWeek: Int): Flow<List<LessonEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLesson(lesson: LessonEntity): Long

    @Update
    suspend fun updateLesson(lesson: LessonEntity)

    @Query("DELETE FROM lessons WHERE id = :id")
    suspend fun deleteLesson(id: Long)
}

@Dao
interface PrayerDao {
    @Query("SELECT * FROM prayer_records WHERE date = :date")
    fun getPrayerRecord(date: String): Flow<PrayerRecordEntity?>

    @Query("SELECT * FROM prayer_records WHERE date = :date")
    suspend fun getPrayerRecordOnce(date: String): PrayerRecordEntity?

    @Query("SELECT * FROM prayer_records ORDER BY date DESC LIMIT 7")
    fun getRecentPrayerRecords(): Flow<List<PrayerRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePrayerRecord(record: PrayerRecordEntity)
}

@Dao
interface PomodoroDao {
    @Query("SELECT * FROM pomodoro_records WHERE date = :date")
    fun getPomodoroRecord(date: String): Flow<PomodoroRecordEntity?>

    @Query("SELECT * FROM pomodoro_records WHERE date = :date")
    suspend fun getPomodoroRecordOnce(date: String): PomodoroRecordEntity?

    @Query("SELECT * FROM pomodoro_records ORDER BY date DESC LIMIT 7")
    fun getRecentPomodoroRecords(): Flow<List<PomodoroRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePomodoroRecord(record: PomodoroRecordEntity)
}
