package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// =========================================================================
// Eye-Comfort Ergonomic Color System for Students
// Tuned to eliminate specular glare, reduce blue-light fatigue, and provide
// optimal contrast for reading textbooks, Quran, and long study sessions.
// =========================================================================

// 1. Boy Theme: Deep Navy & Slate Teal (هدوء وتركيز ذهني عالي بدون إجهاد للعين)
val BoyNavyPrimary = Color(0xFF1E3A5F) // Calm, deep slate navy (not glaring electric blue)
val BoyNavyOnPrimary = Color(0xFFFFFFFF)
val BoyNavyPrimaryContainer = Color(0xFFDCE8F5) // Soft misty sky blue
val BoyNavyOnPrimaryContainer = Color(0xFF0F2338)
val BoyNavySecondary = Color(0xFF2E6578) // Calming Eucalyptus Teal
val BoyNavySecondaryContainer = Color(0xFFDDF0F4)
val BoyNavyBackground = Color(0xFFF4F7F9) // Eye-safe matte paper off-white (anti-glare)
val BoyNavySurface = Color(0xFFFFFFFF)
val BoyNavySurfaceVariant = Color(0xFFE9EFF5)
val BoyNavyOutline = Color(0xFFB8C8D8)

// Boy Eye-Comfort Dark Mode (Midnight Slate, no harsh pure OLED contrast)
val BoyDarkBackground = Color(0xFF0F1722) // Deep non-harsh night sky
val BoyDarkSurface = Color(0xFF172232)
val BoyDarkSurfaceVariant = Color(0xFF213044)
val BoyDarkPrimary = Color(0xFF7EAAD8) // Soft pastel slate blue
val BoyDarkSecondary = Color(0xFF67B0C2)
val BoyDarkOnSurface = Color(0xFFE5EDF4) // Warm white, no harsh flash

// 2. Girl Theme: Warm Dusty Rose & Mauve (ألوان ترابية وردية هادئة مريحة للعين)
val GirlPinkPrimary = Color(0xFF8C3E56) // Muted warm dusty rose (low blue-light, eye-comfort)
val GirlPinkOnPrimary = Color(0xFFFFFFFF)
val GirlPinkPrimaryContainer = Color(0xFFF7E2EB) // Warm blush mist
val GirlPinkOnPrimaryContainer = Color(0xFF3F1321)
val GirlPinkSecondary = Color(0xFF6B5173) // Gentle soothing heather lavender
val GirlPinkSecondaryContainer = Color(0xFFEFE4F3)
val GirlPinkBackground = Color(0xFFFAF5F6) // Warm soothing cream with subtle rose warmth
val GirlPinkSurface = Color(0xFFFFFFFF)
val GirlPinkSurfaceVariant = Color(0xFFF4E8EC)
val GirlPinkOutline = Color(0xFFDEC3CD)

// Girl Eye-Comfort Dark Mode (Deep Mauve Twilight)
val GirlDarkBackground = Color(0xFF1A1117)
val GirlDarkSurface = Color(0xFF251921)
val GirlDarkSurfaceVariant = Color(0xFF33242E)
val GirlDarkPrimary = Color(0xFFD68A9F) // Soft gentle rose pastel
val GirlDarkSecondary = Color(0xFFB99BC0)
val GirlDarkOnSurface = Color(0xFFF3E7ED)

// 3. Eye-Comfort Sepia Paper Theme: (وضع راحة العين المعتمد طبياً - ورق السيبيا الدافئ)
val SepiaPrimary = Color(0xFF634832) // Warm bookbinder bronze
val SepiaOnPrimary = Color(0xFFFFFFFF)
val SepiaPrimaryContainer = Color(0xFFEFE3D5) // Warm parchment
val SepiaOnPrimaryContainer = Color(0xFF2F1F13)
val SepiaSecondary = Color(0xFF5E6047) // Gentle olive sage
val SepiaSecondaryContainer = Color(0xFFE4E8D3)
val SepiaBackground = Color(0xFFF7F3EB) // Classic Warm Paper background (Kindle/e-reader style)
val SepiaSurface = Color(0xFFFDFBF7)
val SepiaSurfaceVariant = Color(0xFFECE5DA)
val SepiaOutline = Color(0xFFD2C7B6)

// Sepia Eye-Comfort Dark (Warm Amber Charcoal)
val SepiaDarkBackground = Color(0xFF171411)
val SepiaDarkSurface = Color(0xFF221E19)
val SepiaDarkSurfaceVariant = Color(0xFF302B24)
val SepiaDarkPrimary = Color(0xFFCFB396)
val SepiaDarkSecondary = Color(0xFFB0B595)
val SepiaDarkOnSurface = Color(0xFFEFEBE4)

// Study session ambiance background colors (eye-friendly dark tones)
val AmbianceDefault = Color(0xFF16202E)
val AmbianceSage = Color(0xFF152A20)
val AmbianceWarmWood = Color(0xFF2A1C15)
val AmbianceDeepIndigo = Color(0xFF17162C)
val AmbianceMidnight = Color(0xFF0F1722)
val AmbianceSoftRose = Color(0xFF26141D)
