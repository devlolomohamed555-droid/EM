package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AdhkarCategory
import com.example.data.model.AdhkarItem
import com.example.data.model.QuranReciter
import com.example.data.model.Surah
import com.example.data.repository.EducationalData
import com.example.ui.viewmodels.MainViewModel
import com.example.utils.TimeUtils
import com.google.android.gms.location.LocationServices

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IslamicScreen(
    viewModel: MainViewModel,
    initialTab: Int = 0
) {
    var selectedTabIndex by remember { mutableStateOf(initialTab) }
    val tabs = listOf("القرآن الكريم والتلاوات", "مواقيت الصلاة", "الأذكار والأدعية")

    val audioIsPlaying by viewModel.audioIsPlaying.collectAsStateWithLifecycle()
    val audioCurrentTitle by viewModel.audioCurrentTitle.collectAsStateWithLifecycle()
    val audioPosition by viewModel.audioCurrentPositionMs.collectAsStateWithLifecycle()
    val audioDuration by viewModel.audioDurationMs.collectAsStateWithLifecycle()
    val audioIsLoading by viewModel.audioIsLoading.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Tab Header
            PrimaryTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTabIndex) {
                    0 -> QuranSection(viewModel = viewModel)
                    1 -> PrayerTimesSection(viewModel = viewModel)
                    2 -> AdhkarSection(viewModel = viewModel)
                }
            }
        }

        // Persistent Mini Audio Player across the Islamic Screen
        if (audioCurrentTitle.isNotBlank()) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .shadow(10.dp, RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceColorAtElevation(6.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                modifier = Modifier.size(38.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (audioIsLoading) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(18.dp),
                                            strokeWidth = 2.dp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.VolumeUp,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = audioCurrentTitle,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${TimeUtils.formatMillis(audioPosition)} / ${TimeUtils.formatMillis(audioDuration)}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.rewindAudio() }) {
                                Icon(
                                    imageVector = Icons.Default.Replay10,
                                    contentDescription = "تأخير 10 ثوانٍ",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            FilledIconButton(
                                onClick = { viewModel.toggleAudioPlayPause() },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = if (audioIsPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (audioIsPlaying) "إيقاف" else "تشغيل",
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            IconButton(onClick = { viewModel.forwardAudio() }) {
                                Icon(
                                    imageVector = Icons.Default.Forward10,
                                    contentDescription = "تقديم 10 ثوانٍ",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            IconButton(onClick = { viewModel.stopAudio() }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق المشغل",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    if (audioDuration > 0) {
                        Slider(
                            value = (audioPosition.toFloat() / audioDuration.toFloat()).coerceIn(0f, 1f),
                            onValueChange = { frac ->
                                viewModel.seekAudio((frac * audioDuration).toInt())
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(16.dp)
                        )
                    }
                }
            }
        }
    }
}

// ------------------- 1. QURAN & AUDIO RECITATION SECTION -------------------
@Composable
fun QuranSection(viewModel: MainViewModel) {
    val surahs by viewModel.surahs.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoadingQuran.collectAsStateWithLifecycle()
    val selectedSurahDetail by viewModel.selectedSurahDetail.collectAsStateWithLifecycle()
    val selectedReciter by viewModel.selectedReciter.collectAsStateWithLifecycle()
    val audioIsPlaying by viewModel.audioIsPlaying.collectAsStateWithLifecycle()
    val currentPlayingSurahNumber by viewModel.audioCurrentSurahNumber.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var showReciterDialog by remember { mutableStateOf(false) }

    val filteredSurahs = remember(surahs, searchQuery) {
        if (searchQuery.isBlank()) surahs
        else surahs.filter {
            it.name.contains(searchQuery) ||
            it.englishName.contains(searchQuery, ignoreCase = true) ||
            it.number.toString() == searchQuery.trim()
        }
    }

    if (selectedSurahDetail != null) {
        // Full Surah Reading & Audio Playing View
        SurahReaderView(
            surahPair = selectedSurahDetail!!,
            viewModel = viewModel,
            onClose = {
                // Return to Surah list
                viewModel.openSurah(-1)
            }
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Reciter Selection Header Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showReciterDialog = true },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier
                                    .padding(8.dp)
                                    .size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "القارئ الصوتي الحالي:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "الشيخ ${selectedReciter.name} (${selectedReciter.subName})",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = { showReciterDialog = true },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تغيير القارئ", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث عن سورة بالاسم أو الرقم...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (isLoading && surahs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(filteredSurahs, key = { it.number }) { surah ->
                        val isThisSurahPlaying = audioIsPlaying && currentPlayingSurahNumber == surah.number

                        SurahListItem(
                            surah = surah,
                            isPlaying = isThisSurahPlaying,
                            onClick = { viewModel.openSurah(surah.number) },
                            onPlayAudio = {
                                if (isThisSurahPlaying) {
                                    viewModel.toggleAudioPlayPause()
                                } else {
                                    viewModel.playSurahAudio(surah.number, surah.name)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Reciters Dialog
    if (showReciterDialog) {
        AlertDialog(
            onDismissRequest = { showReciterDialog = false },
            title = {
                Text(
                    text = "اختر القارئ المفضل للتلاوة الصوتية",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    viewModel.defaultReciters.forEach { reciter ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    viewModel.setReciter(reciter)
                                    showReciterDialog = false
                                }
                                .background(
                                    if (selectedReciter.id == reciter.id)
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                    else Color.Transparent
                                )
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedReciter.id == reciter.id,
                                onClick = {
                                    viewModel.setReciter(reciter)
                                    showReciterDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "الشيخ ${reciter.name}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = reciter.subName,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReciterDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

@Composable
fun SurahListItem(
    surah: Surah,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onPlayAudio: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPlaying)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Surah Number badge
                Surface(
                    modifier = Modifier.size(38.dp),
                    shape = CircleShape,
                    color = if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "${surah.number}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPlaying) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = surah.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${surah.englishName} • ${if (surah.revelationType == "Meccan") "مكية" else "مدنية"} • ${surah.numberOfAyahs} آيات",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }

            // Quick Play/Pause Surah Audio Button
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onPlayAudio,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            if (isPlaying) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.secondaryContainer
                        )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "إيقاف السورة" else "تشغيل السورة كاملة بالصوت",
                        tint = if (isPlaying) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = "قراءة",
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

// Fullscreen Surah Reader with Complete Audio Bar & Ayah Audio
@Composable
fun SurahReaderView(
    surahPair: Pair<Surah, List<com.example.data.model.Ayah>>,
    viewModel: MainViewModel,
    onClose: () -> Unit
) {
    val surah = surahPair.first
    val ayahs = surahPair.second

    val audioIsPlaying by viewModel.audioIsPlaying.collectAsStateWithLifecycle()
    val audioPosition by viewModel.audioCurrentPositionMs.collectAsStateWithLifecycle()
    val audioDuration by viewModel.audioDurationMs.collectAsStateWithLifecycle()
    val audioIsLoading by viewModel.audioIsLoading.collectAsStateWithLifecycle()
    val currentSurahNum by viewModel.audioCurrentSurahNumber.collectAsStateWithLifecycle()
    val selectedReciter by viewModel.selectedReciter.collectAsStateWithLifecycle()

    var playingAyahNumber by remember { mutableStateOf(-1) }
    val isCurrentSurahPlaying = audioIsPlaying && currentSurahNum == surah.number

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Surah Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق القارئ"
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = surah.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "القارئ: الشيخ ${selectedReciter.name} (${surah.numberOfAyahs} آيات)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                IconButton(
                    onClick = {
                        if (isCurrentSurahPlaying) {
                            viewModel.toggleAudioPlayPause()
                        } else {
                            viewModel.playSurahAudio(surah.number, surah.name)
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (isCurrentSurahPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                        contentDescription = "تشغيل السورة",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }

        // Dedicated Surah Audio Controller Header Bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isCurrentSurahPlaying) "جارٍ الاستماع لسورة ${surah.name}" else "استماع للتلاوة الكاملة",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.rewindAudio() },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Default.Replay10, contentDescription = "10s", modifier = Modifier.size(20.dp))
                        }

                        FilledIconButton(
                            onClick = {
                                if (isCurrentSurahPlaying) {
                                    viewModel.toggleAudioPlayPause()
                                } else {
                                    viewModel.playSurahAudio(surah.number, surah.name)
                                }
                            },
                            modifier = Modifier.size(40.dp)
                        ) {
                            if (audioIsLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            } else {
                                Icon(
                                    imageVector = if (isCurrentSurahPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = null
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.forwardAudio() },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Default.Forward10, contentDescription = "10s", modifier = Modifier.size(20.dp))
                        }
                    }
                }

                if (isCurrentSurahPlaying && audioDuration > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = TimeUtils.formatMillis(audioPosition),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Slider(
                            value = (audioPosition.toFloat() / audioDuration.toFloat()).coerceIn(0f, 1f),
                            onValueChange = { frac ->
                                viewModel.seekAudio((frac * audioDuration).toInt())
                            },
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp)
                        )
                        Text(
                            text = TimeUtils.formatMillis(audioDuration),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        }

        // Ayahs List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Bismillah Header
            if (surah.number != 9) { // At-Tawbah does not start with Bismillah
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            items(ayahs, key = { it.number }) { ayah ->
                val isThisAyahActive = playingAyahNumber == ayah.numberInSurah

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isThisAyahActive)
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                        else MaterialTheme.colorScheme.surface
                    ),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    text = "آية ${ayah.numberInSurah}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }

                            // Ayah audio button
                            if (ayah.audioUrl.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        playingAyahNumber = ayah.numberInSurah
                                        viewModel.playAyahAudio(ayah.audioUrl, "${surah.name} • آية ${ayah.numberInSurah}")
                                    },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isThisAyahActive && audioIsPlaying) Icons.Default.PauseCircle else Icons.Default.VolumeUp,
                                        contentDescription = "استماع للآية",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = ayah.text,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Normal,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 34.sp,
                            textAlign = TextAlign.Start
                        )
                    }
                }
            }
        }
    }
}

// ------------------- 2. PRAYER TIMES & DAILY COMPLETION TRACKER -------------------
@Composable
fun PrayerTimesSection(viewModel: MainViewModel) {
    val context = LocalContext.current
    val timings by viewModel.prayerTiming.collectAsStateWithLifecycle()
    val todayRecord by viewModel.todayPrayerRecord.collectAsStateWithLifecycle()

    // GPS location launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                    if (loc != null) {
                        viewModel.updateLocation(loc.latitude, loc.longitude)
                    }
                }
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Daily Prayer Completion Tracker
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(3.dp, RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "متابعة صلوات اليوم المفروضة",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            val completed = todayRecord?.completedCount ?: 0
                            Text(
                                text = if (completed == 5) "بارك الله فيك! أتممت جميع صلواتك اليوم 🌟" else "أنجزت $completed من 5 صلوات اليوم",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }

                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = "${todayRecord?.completedCount ?: 0}/5",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LinearProgressIndicator(
                        progress = { ((todayRecord?.completedCount ?: 0) / 5f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Prayer checkboxes
                    val prayers = listOf(
                        Triple("الفجر", "fajr", todayRecord?.fajr ?: false),
                        Triple("الظهر", "dhuhr", todayRecord?.dhuhr ?: false),
                        Triple("العصر", "asr", todayRecord?.asr ?: false),
                        Triple("المغرب", "maghrib", todayRecord?.maghrib ?: false),
                        Triple("العشاء", "isha", todayRecord?.isha ?: false)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        prayers.forEach { (arabicName, key, isDone) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    viewModel.togglePrayer(key, !isDone)
                                }
                            ) {
                                Checkbox(
                                    checked = isDone,
                                    onCheckedChange = { checked ->
                                        viewModel.togglePrayer(key, checked)
                                    }
                                )
                                Text(
                                    text = arabicName,
                                    fontSize = 12.sp,
                                    fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }
        }

        // GPS Location & Date Card
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مواقيت الصلاة حسب موقعك الجغرافي",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${timings.dateReadable} • ${timings.hijriDate}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                FilledTonalButton(
                    onClick = {
                        locationPermissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    }
                ) {
                    Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تحديث GPS", fontSize = 11.sp)
                }
            }
        }

        // Prayer timing list
        item {
            val prayerRows = listOf(
                Pair("صلاة الفجر", timings.fajr),
                Pair("الشروق", timings.sunrise),
                Pair("صلاة الظهر", timings.dhuhr),
                Pair("صلاة العصر", timings.asr),
                Pair("صلاة المغرب", timings.maghrib),
                Pair("صلاة العشاء", timings.isha)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    prayerRows.forEachIndexed { idx, (name, time) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccessTime,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Text(
                                text = time,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        if (idx < prayerRows.size - 1) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

// ------------------- 3. ADHKAR SECTION -------------------
@Composable
fun AdhkarSection(viewModel: MainViewModel) {
    var selectedCategory by remember { mutableStateOf(AdhkarCategory.MORNING) }

    val categoryTabs = listOf(
        Pair(AdhkarCategory.MORNING, "أذكار الصباح"),
        Pair(AdhkarCategory.EVENING, "أذكار المساء"),
        Pair(AdhkarCategory.SLEEP, "أذكار النوم"),
        Pair(AdhkarCategory.STUDY, "أدعية المذاكرة")
    )

    val currentItems = remember(selectedCategory) {
        EducationalData.adhkarContent.filter { it.category == selectedCategory }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        ScrollableTabRow(
            selectedTabIndex = categoryTabs.indexOfFirst { it.first == selectedCategory },
            edgePadding = 0.dp,
            divider = {}
        ) {
            categoryTabs.forEach { (cat, title) ->
                Tab(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    text = {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            items(currentItems, key = { it.id }) { item ->
                InteractiveDhikrCard(item = item)
            }
        }
    }
}

@Composable
fun InteractiveDhikrCard(item: AdhkarItem) {
    var countRemaining by remember(item.id) { mutableStateOf(item.count) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (countRemaining > 0) countRemaining -= 1
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (countRemaining == 0)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
            else MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 26.sp
                )

                if (item.benefit.isNotBlank()) {
                    Text(
                        text = "الفضل: ${item.benefit}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Surface(
                modifier = Modifier.size(52.dp),
                shape = CircleShape,
                color = if (countRemaining == 0)
                    MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.secondaryContainer
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (countRemaining == 0) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "تم",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text(
                            text = "$countRemaining",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }
    }
}
