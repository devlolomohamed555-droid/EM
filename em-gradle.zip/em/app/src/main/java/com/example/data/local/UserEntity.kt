package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "طالب مجتهد",
    val email: String = "student@example.com",
    val isGuest: Boolean = true,
    val gradeId: String = "bac_2",
    val streamId: String = "bac_2_pc",
    val genderTheme: String = "boy", // "boy" (Navy/Blue) or "girl" (Pink/Soft)
    val pomodoroFocusMinutes: Int = 25,
    val pomodoroBreakMinutes: Int = 5,
    val pomodoroBackgroundTheme: Int = 0 // 0: Default, 1: Sage, 2: Rose, 3: Indigo, 4: Warm Sand
)
