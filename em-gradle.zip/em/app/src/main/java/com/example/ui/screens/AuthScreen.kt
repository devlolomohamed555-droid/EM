package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.EducationalData
import com.example.ui.viewmodels.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: MainViewModel,
    onLoginSuccess: () -> Unit
) {
    var selectedGender by remember { mutableStateOf("boy") }
    var selectedGradeId by remember { mutableStateOf("bac_2") }
    var selectedStreamId by remember { mutableStateOf("bac_2_pc") }
    var showSetupDialog by remember { mutableStateOf(false) }
    var isGuestLogin by remember { mutableStateOf(true) }

    val currentGrade = EducationalData.grades.find { it.id == selectedGradeId } ?: EducationalData.grades.first()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(32.dp))

            // 3D Styled Logo matching PDF Page 1
            Surface(
                modifier = Modifier
                    .size(120.dp)
                    .shadow(12.dp, RoundedCornerShape(28.dp)),
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "EM",
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 2.sp
                        )
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = "قبعة التخرج",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "بكالوريا وثانوية عامة",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "المساعد الدراسي الذكي الشامل",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))

            Text(
                text = "سجل الدخول الآن",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Google Sign-In Button (matches design)
            Button(
                onClick = {
                    isGuestLogin = false
                    showSetupDialog = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .shadow(4.dp, RoundedCornerShape(28.dp))
                    .testTag("google_login_button"),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary
                ),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "جوجل",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Continue as Guest Button (matches design)
            Button(
                onClick = {
                    isGuestLogin = true
                    showSetupDialog = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .shadow(4.dp, RoundedCornerShape(28.dp))
                    .testTag("guest_login_button"),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary
                ),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "كضيف",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Footer branding
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Text(
                    text = "EM Student Assistant • صُمم خصيصاً للنجاح والتفوق",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }
    }

    // Onboarding & Setup Dialog
    if (showSetupDialog) {
        AlertDialog(
            onDismissRequest = { showSetupDialog = false },
            title = {
                Text(
                    text = "إعداد الحساب الدراسي",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. Theme Choice
                    Text(
                        text = "1/ مظهر التطبيق المريح للعين:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedGender == "boy",
                                onClick = { selectedGender = "boy" },
                                label = { Text("أزرق كحلي هادئ", fontSize = 12.sp) },
                                modifier = Modifier.weight(1f),
                                leadingIcon = if (selectedGender == "boy") {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null
                            )

                            FilterChip(
                                selected = selectedGender == "girl",
                                onClick = { selectedGender = "girl" },
                                label = { Text("وردي دافئ ناعم", fontSize = 12.sp) },
                                modifier = Modifier.weight(1f),
                                leadingIcon = if (selectedGender == "girl") {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null
                            )
                        }

                        FilterChip(
                            selected = selectedGender == "eye_comfort",
                            onClick = { selectedGender = "eye_comfort" },
                            label = { Text("وضع راحة العين (ورق سيبيا دافئ للقراءة)", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = if (selectedGender == "eye_comfort") {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null
                        )
                    }

                    HorizontalDivider()

                    // 2. Grade Choice
                    Text(
                        text = "2/ اختر مرحلتك الدراسية:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    EducationalData.grades.forEach { grade ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (selectedGradeId == grade.id)
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                    else Color.Transparent
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedGradeId == grade.id,
                                onClick = {
                                    selectedGradeId = grade.id
                                    selectedStreamId = grade.streams.firstOrNull()?.id ?: ""
                                }
                            )
                            Text(
                                text = grade.name,
                                fontSize = 14.sp,
                                fontWeight = if (selectedGradeId == grade.id) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }

                    // 3. Stream Choice
                    if (currentGrade.streams.size > 1) {
                        Text(
                            text = "الشعبة أو التخصص:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )

                        currentGrade.streams.forEach { stream ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (selectedStreamId == stream.id)
                                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                                        else Color.Transparent
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedStreamId == stream.id,
                                    onClick = { selectedStreamId = stream.id }
                                )
                                Text(
                                    text = stream.name,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = if (isGuestLogin) "طالب ضيف" else "طالب متميز"
                        val email = if (isGuestLogin) "guest@em.student" else "student@gmail.com"
                        viewModel.saveUserNameAndEmail(name, email, isGuestLogin)
                        viewModel.toggleGenderTheme(selectedGender)
                        viewModel.updateGradeAndStream(selectedGradeId, selectedStreamId)
                        showSetupDialog = false
                        onLoginSuccess()
                    },
                    modifier = Modifier.testTag("confirm_setup_button")
                ) {
                    Text("ابدأ الدراسة الآن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSetupDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
