package com.example.utils

import com.example.data.local.LessonEntity
import com.example.data.model.NextPrayerInfo
import com.example.data.model.PrayerTiming
import java.text.SimpleDateFormat
import java.util.*

object TimeUtils {

    fun calculateNextPrayer(timings: PrayerTiming): NextPrayerInfo {
        val calendar = Calendar.getInstance()
        val nowMillis = calendar.timeInMillis

        val prayerList = listOf(
            Triple("Fajr", "صلاة الفجر", timings.fajr),
            Triple("Dhuhr", "صلاة الظهر", timings.dhuhr),
            Triple("Asr", "صلاة العصر", timings.asr),
            Triple("Maghrib", "صلاة المغرب", timings.maghrib),
            Triple("Isha", "صلاة العشاء", timings.isha)
        )

        val timeFormat = SimpleDateFormat("HH:mm", Locale.US)

        for ((name, arName, timeStr) in prayerList) {
            try {
                val cleanTime = timeStr.split(" ")[0].trim()
                val parts = cleanTime.split(":")
                if (parts.size >= 2) {
                    val prayerCal = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                        set(Calendar.MINUTE, parts[1].toInt())
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    val diff = prayerCal.timeInMillis - nowMillis
                    if (diff > 0) {
                        return NextPrayerInfo(name, arName, cleanTime, diff)
                    }
                }
            } catch (e: Exception) {
                // Continue
            }
        }

        // If all prayers today have passed, next is tomorrow's Fajr
        try {
            val cleanFajr = timings.fajr.split(" ")[0].trim()
            val parts = cleanFajr.split(":")
            val tomorrowFajrCal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                set(Calendar.MINUTE, parts[1].toInt())
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val diff = tomorrowFajrCal.timeInMillis - nowMillis
            return NextPrayerInfo("Fajr", "صلاة الفجر", cleanFajr, diff)
        } catch (e: Exception) {
            return NextPrayerInfo("Fajr", "صلاة الفجر", "04:35", 3600000L)
        }
    }

    fun calculateNextLesson(lessons: List<LessonEntity>): Pair<LessonEntity?, Long> {
        if (lessons.isEmpty()) return Pair(null, -1L)

        val cal = Calendar.getInstance()
        val currentDay = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday, 7 = Saturday
        val currentHour = cal.get(Calendar.HOUR_OF_DAY)
        val currentMinute = cal.get(Calendar.MINUTE)
        val nowMinuteOfDay = currentHour * 60 + currentMinute

        var candidateLesson: LessonEntity? = null
        var minDiffMinutes = Long.MAX_VALUE

        for (lesson in lessons) {
            try {
                val parts = lesson.startTime.split(":")
                if (parts.size >= 2) {
                    val lessonMinuteOfDay = parts[0].toInt() * 60 + parts[1].toInt()
                    // Calculate day offset
                    val dayDiff = (lesson.dayOfWeek - currentDay + 7) % 7
                    val totalDiffMinutes = if (dayDiff == 0) {
                        if (lessonMinuteOfDay > nowMinuteOfDay) {
                            (lessonMinuteOfDay - nowMinuteOfDay).toLong()
                        } else {
                            (7 * 24 * 60 - (nowMinuteOfDay - lessonMinuteOfDay)).toLong()
                        }
                    } else {
                        (dayDiff * 24 * 60 + (lessonMinuteOfDay - nowMinuteOfDay)).toLong()
                    }

                    if (totalDiffMinutes in 1 until minDiffMinutes) {
                        minDiffMinutes = totalDiffMinutes
                        candidateLesson = lesson
                    }
                }
            } catch (e: Exception) {
                // Ignore parsing errors
            }
        }

        return if (candidateLesson != null && minDiffMinutes != Long.MAX_VALUE) {
            Pair(candidateLesson, minDiffMinutes * 60 * 1000L)
        } else {
            Pair(null, -1L)
        }
    }

    fun formatDurationHoursMinutes(millis: Long): String {
        if (millis <= 0) return "0 د"
        val totalSeconds = millis / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return when {
            hours > 0 -> "$hours س و $minutes د و $seconds ث"
            minutes > 0 -> "$minutes د و $seconds ث"
            else -> "$seconds ثوانٍ"
        }
    }

    fun formatMinutesSeconds(totalSeconds: Int): String {
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    fun formatMillis(millis: Int): String {
        if (millis <= 0) return "00:00"
        val totalSeconds = millis / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    fun getArabicDayName(dayOfWeek: Int): String {
        return when (dayOfWeek) {
            Calendar.SUNDAY -> "الأحد"
            Calendar.MONDAY -> "الاثنين"
            Calendar.TUESDAY -> "الثلاثاء"
            Calendar.WEDNESDAY -> "الأربعاء"
            Calendar.THURSDAY -> "الخميس"
            Calendar.FRIDAY -> "الجمعة"
            Calendar.SATURDAY -> "السبت"
            else -> ""
        }
    }
}
