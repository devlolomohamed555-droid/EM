package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pomodoro_records")
data class PomodoroRecordEntity(
    @PrimaryKey val date: String, // "YYYY-MM-DD"
    val focusMinutes: Int = 0,
    val sessionsCompleted: Int = 0
) {
    val focusHours: Float
        get() = focusMinutes / 60f
}
