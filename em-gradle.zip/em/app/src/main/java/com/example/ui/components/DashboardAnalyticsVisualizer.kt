package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.PomodoroRecordEntity
import com.example.data.local.PrayerRecordEntity
import com.example.ui.viewmodels.MainViewModel
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

data class DayFocusData(
    val dayLabel: String,
    val dateStr: String,
    val focusHours: Float,
    val isToday: Boolean
)

data class DayPrayerData(
    val dayLabel: String,
    val dateStr: String,
    val completedPrayers: Int,
    val isToday: Boolean
)

@Composable
fun DashboardAnalyticsCard(
    viewModel: MainViewModel,
    onNavigateToStudy: () -> Unit,
    onNavigateToIslamic: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pomodoroRecords by viewModel.recentPomodoros.collectAsStateWithLifecycle()
    val prayerRecords by viewModel.recentPrayers.collectAsStateWithLifecycle()
    val todayPrayer by viewModel.todayPrayerRecord.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Pomodoro, 1: Prayers

    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .animateContentSize()
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (selectedTab == 0) Icons.Default.BarChart else Icons.Default.DonutLarge,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "مؤشرات الإنجاز والإنتاجية (Canvas)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (selectedTab == 0) "ساعات تركيز البومودورو اليومية" else "نسبة أداء وإتمام الصلوات الخمس",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                TextButton(
                    onClick = if (selectedTab == 0) onNavigateToStudy else onNavigateToIslamic,
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text(
                        text = if (selectedTab == 0) "المؤقت ⤢" else "الصلوات ⤢",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tab Selector (Pomodoro Focus vs Prayers)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val tabPrimary = MaterialTheme.colorScheme.primary
                val tabSurface = MaterialTheme.colorScheme.surface

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { selectedTab = 0 },
                    color = if (selectedTab == 0) tabSurface else Color.Transparent,
                    shadowElevation = if (selectedTab == 0) 2.dp else 0.dp,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = if (selectedTab == 0) tabPrimary else MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ساعات التركيز (بومودورو)",
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 0) tabPrimary else MaterialTheme.colorScheme.outline
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { selectedTab = 1 },
                    color = if (selectedTab == 1) tabSurface else Color.Transparent,
                    shadowElevation = if (selectedTab == 1) 2.dp else 0.dp,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = if (selectedTab == 1) tabPrimary else MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "إتمام الصلوات الخمس",
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == 1) tabPrimary else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Chart Content based on active tab
            if (selectedTab == 0) {
                PomodoroFocusHoursCanvasChart(pomodoroRecords = pomodoroRecords)
            } else {
                PrayerCompletionRatesCanvasChart(
                    prayerRecords = prayerRecords,
                    todayRecord = todayPrayer
                )
            }
        }
    }
}

/**
 * Native Jetpack Compose Canvas Bar Chart for Daily Pomodoro Focus Hours.
 * Adheres strictly to DrawScope size-based graphics without external pixel measurements.
 */
@Composable
fun PomodoroFocusHoursCanvasChart(
    pomodoroRecords: List<PomodoroRecordEntity>,
    modifier: Modifier = Modifier
) {
    // Generate 7 days ending today
    val calendar = Calendar.getInstance()
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val dayFormat = SimpleDateFormat("EEE", Locale("ar"))

    val daysData = remember(pomodoroRecords) {
        val list = mutableListOf<DayFocusData>()
        val recordsMap = pomodoroRecords.associateBy { it.date }

        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val dateStr = sdf.format(cal.time)
            val record = recordsMap[dateStr]
            val hours = record?.focusHours ?: 0f
            val isToday = (i == 0)
            val label = if (isToday) "اليوم" else dayFormat.format(cal.time)
            list.add(DayFocusData(label, dateStr, hours, isToday))
        }
        list
    }

    val maxHours = remember(daysData) {
        val maxVal = daysData.maxOfOrNull { it.focusHours } ?: 1f
        max(4.0f, maxVal * 1.15f) // minimum scale of 4 hours
    }

    val totalHoursWeek = remember(daysData) { daysData.sumOf { it.focusHours.toDouble() }.toFloat() }
    val averageHoursDaily = remember(daysData) { totalHoursWeek / 7f }
    val bestDay = remember(daysData) { daysData.maxByOrNull { it.focusHours } }

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val primaryContainer = MaterialTheme.colorScheme.primaryContainer
    val outlineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant

    Column(modifier = modifier.fillMaxWidth()) {
        // Stats Summary Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            StatPill(
                label = "مجموع الأسبوع",
                value = String.format(Locale.US, "%.1f س", totalHoursWeek),
                color = primaryColor
            )
            StatPill(
                label = "المعدل اليومي",
                value = String.format(Locale.US, "%.1f س/يوم", averageHoursDaily),
                color = secondaryColor
            )
            StatPill(
                label = "أفضل إنجاز",
                value = String.format(Locale.US, "%.1f س (${bestDay?.dayLabel ?: ""})", bestDay?.focusHours ?: 0f),
                color = MaterialTheme.colorScheme.tertiary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Native Jetpack Compose Canvas for Bars, Grids, and Targets
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val bottomPadding = 4f
                val chartHeight = canvasHeight - bottomPadding

                // 1. Draw horizontal guide lines (1h, 2h, 3h, 4h)
                val steps = 4
                for (step in 1..steps) {
                    val targetH = (maxHours / steps) * step
                    val y = chartHeight - (targetH / maxHours) * chartHeight
                    drawLine(
                        color = outlineColor,
                        start = Offset(0f, y),
                        end = Offset(canvasWidth, y),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }

                // 2. Draw Average Daily Focus guideline
                val avgY = chartHeight - (averageHoursDaily / maxHours) * chartHeight
                drawLine(
                    color = secondaryColor.copy(alpha = 0.5f),
                    start = Offset(0f, avgY),
                    end = Offset(canvasWidth, avgY),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 8f), 0f)
                )

                // 3. Draw Bars for the 7 Days
                val barCount = daysData.size
                val slotWidth = canvasWidth / barCount
                val barWidth = slotWidth * 0.52f

                daysData.forEachIndexed { index, day ->
                    val centerX = (index + 0.5f) * slotWidth
                    val left = centerX - barWidth / 2f

                    // Calculate height proportional to DrawScope height
                    val barH = if (maxHours > 0f) {
                        ((day.focusHours / maxHours) * chartHeight).coerceAtLeast(6f)
                    } else 6f

                    val top = chartHeight - barH

                    // Background Track Pill for each bar
                    drawRoundRect(
                        color = surfaceVariant.copy(alpha = 0.4f),
                        topLeft = Offset(left, 0f),
                        size = Size(barWidth, chartHeight),
                        cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                    )

                    // Active Bar with Gradient
                    val barBrush = if (day.isToday) {
                        Brush.verticalGradient(
                            colors = listOf(primaryColor, secondaryColor),
                            startY = top,
                            endY = chartHeight
                        )
                    } else {
                        Brush.verticalGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = 0.85f),
                                primaryColor.copy(alpha = 0.4f)
                            ),
                            startY = top,
                            endY = chartHeight
                        )
                    }

                    drawRoundRect(
                        brush = barBrush,
                        topLeft = Offset(left, top),
                        size = Size(barWidth, barH),
                        cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                    )

                    // Glow or highlight dot on today's bar
                    if (day.isToday) {
                        drawCircle(
                            color = primaryColor,
                            radius = 3.5.dp.toPx(),
                            center = Offset(centerX, top - 6.dp.toPx())
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // X-Axis Labels (Day Names) using Compose Row for RTL & typography scalability
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            daysData.forEach { day ->
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = day.dayLabel,
                        fontSize = 11.sp,
                        fontWeight = if (day.isToday) FontWeight.Bold else FontWeight.Normal,
                        color = if (day.isToday) primaryColor else MaterialTheme.colorScheme.outline
                    )
                    Text(
                        text = if (day.focusHours > 0f) String.format(Locale.US, "%.1fh", day.focusHours) else "-",
                        fontSize = 9.sp,
                        fontWeight = if (day.isToday) FontWeight.Bold else FontWeight.Normal,
                        color = if (day.isToday) primaryColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

/**
 * Native Jetpack Compose Canvas Chart for Daily Prayer Completion Rates.
 * Combines a circular radial progress gauge for today's 5 prayers with a 7-day completion rate track.
 */
@Composable
fun PrayerCompletionRatesCanvasChart(
    prayerRecords: List<PrayerRecordEntity>,
    todayRecord: PrayerRecordEntity?,
    modifier: Modifier = Modifier
) {
    val completedToday = todayRecord?.completedCount ?: 0
    val todayPercentage = (completedToday / 5f) * 100f

    val calendar = Calendar.getInstance()
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val dayFormat = SimpleDateFormat("EEE", Locale("ar"))

    val weeklyData = remember(prayerRecords, todayRecord) {
        val list = mutableListOf<DayPrayerData>()
        val recordsMap = prayerRecords.associateBy { it.date }

        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val dateStr = sdf.format(cal.time)
            val isToday = (i == 0)
            val count = if (isToday) completedToday else (recordsMap[dateStr]?.completedCount ?: 0)
            val label = if (isToday) "اليوم" else dayFormat.format(cal.time)
            list.add(DayPrayerData(label, dateStr, count, isToday))
        }
        list
    }

    val totalCompletedWeekly = remember(weeklyData) { weeklyData.sumOf { it.completedPrayers } }
    val totalPossibleWeekly = 35 // 7 days * 5 prayers
    val weeklyCompletionRate = remember(totalCompletedWeekly) {
        (totalCompletedWeekly.toFloat() / totalPossibleWeekly.toFloat()) * 100f
    }

    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.secondary
    val successColor = Color(0xFF2E7D32)
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Radial Donut Gauge (Native Canvas)
            Box(
                modifier = Modifier
                    .size(110.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 12.dp.toPx()
                    val diameter = size.minDimension - strokeWidth
                    val radius = diameter / 2f
                    val centerOffset = Offset(size.width / 2f, size.height / 2f)

                    // Background Track
                    drawCircle(
                        color = surfaceVariant.copy(alpha = 0.5f),
                        radius = radius,
                        center = centerOffset,
                        style = Stroke(width = strokeWidth)
                    )

                    // Foreground Animated / Computed Arc (start from top -90 deg)
                    val sweepAngle = (completedToday / 5f) * 360f
                    if (sweepAngle > 0f) {
                        drawArc(
                            brush = Brush.sweepGradient(
                                colors = listOf(primaryColor, secondaryColor, primaryColor),
                                center = centerOffset
                            ),
                            startAngle = -90f,
                            sweepAngle = sweepAngle,
                            useCenter = false,
                            topLeft = Offset(centerOffset.x - radius, centerOffset.y - radius),
                            size = Size(radius * 2f, radius * 2f),
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                }

                // Center Text Inside Donut
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$completedToday/5",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = primaryColor
                    )
                    Text(
                        text = "${todayPercentage.toInt()}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }

            // 2. Today's Individual Prayer Check Indicators
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "فروض اليوم الخمسة:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PrayerMiniBadge("فجر", todayRecord?.fajr == true, primaryColor)
                    PrayerMiniBadge("ظهر", todayRecord?.dhuhr == true, primaryColor)
                    PrayerMiniBadge("عصر", todayRecord?.asr == true, primaryColor)
                    PrayerMiniBadge("مغرب", todayRecord?.maghrib == true, primaryColor)
                    PrayerMiniBadge("عشاء", todayRecord?.isha == true, primaryColor)
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = if (completedToday == 5)
                        "ما شاء الله! أتممت جميع صلوات اليوم في وقتها ✨"
                    else
                        "متبقي لك ${5 - completedToday} صلوات لإتمام أجر اليوم المبارك",
                    fontSize = 11.sp,
                    color = if (completedToday == 5) successColor else MaterialTheme.colorScheme.outline,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(12.dp))

        // 3. Weekly 7-Day Prayer Rate Track (Canvas)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "متابعة إتمام الصلوات للأيام الـ 7 الماضية",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "المعدل: ${weeklyCompletionRate.toInt()}%",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = primaryColor
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 7-day pill columns in native Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(65.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val count = weeklyData.size
                val slotWidth = canvasWidth / count
                val barWidth = slotWidth * 0.46f

                weeklyData.forEachIndexed { index, day ->
                    val centerX = (index + 0.5f) * slotWidth
                    val left = centerX - barWidth / 2f

                    // Full height background track
                    drawRoundRect(
                        color = surfaceVariant.copy(alpha = 0.45f),
                        topLeft = Offset(left, 0f),
                        size = Size(barWidth, canvasHeight),
                        cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                    )

                    // Fill based on completed prayers (0 to 5)
                    val ratio = (day.completedPrayers / 5f).coerceIn(0f, 1f)
                    if (ratio > 0f) {
                        val activeH = canvasHeight * ratio
                        val top = canvasHeight - activeH
                        val color = when (day.completedPrayers) {
                            5 -> successColor
                            in 3..4 -> primaryColor
                            else -> secondaryColor
                        }

                        drawRoundRect(
                            color = if (day.isToday) primaryColor else color.copy(alpha = 0.85f),
                            topLeft = Offset(left, top),
                            size = Size(barWidth, activeH),
                            cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Weekdays row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            weeklyData.forEach { day ->
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = day.dayLabel,
                        fontSize = 10.sp,
                        fontWeight = if (day.isToday) FontWeight.Bold else FontWeight.Normal,
                        color = if (day.isToday) primaryColor else MaterialTheme.colorScheme.outline
                    )
                    Text(
                        text = "${day.completedPrayers}/5",
                        fontSize = 9.sp,
                        fontWeight = if (day.isToday) FontWeight.Bold else FontWeight.Normal,
                        color = if (day.isToday) primaryColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

@Composable
fun PrayerMiniBadge(name: String, done: Boolean, activeColor: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (done) activeColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = if (done) androidx.compose.foundation.BorderStroke(1.dp, activeColor) else null,
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (done) Icons.Default.Check else Icons.Default.Close,
                contentDescription = null,
                tint = if (done) activeColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = name,
                fontSize = 10.sp,
                fontWeight = if (done) FontWeight.Bold else FontWeight.Normal,
                color = if (done) activeColor else MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun StatPill(label: String, value: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.1f),
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.outline
            )
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}
