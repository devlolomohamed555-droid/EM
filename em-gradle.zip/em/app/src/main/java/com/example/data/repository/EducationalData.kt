package com.example.data.repository

import com.example.data.model.*

object EducationalData {

    val ministryBooksPortal = "https://studentbooks.moe.gov.eg/"

    val grades: List<EducationalGrade> = listOf(
        EducationalGrade(
            id = "bac_2",
            name = "ثانية بكالوريا (2ème Bac)",
            stage = StageType.BACCALAUREATE,
            streams = listOf(
                EducationalStream(
                    id = "bac_2_pc",
                    name = "مسلك العلوم الفيزيائية (PC)",
                    subjects = listOf(
                        SubjectItem(
                            id = "bac_2_pc_math",
                            name = "الرياضيات (Mathématiques)",
                            iconName = "calculate",
                            books = listOf(
                                BookPdf("b1", "كتاب المفيد في الرياضيات - 2 باك علوم فيزيائية", "https://studentbooks.moe.gov.eg/", "وزارة التربية الوطنية", "المقرر الرسمي للرياضيات مع التمارين والحلول"),
                                BookPdf("b2", "سلسلة ملخصات الرياضيات والامتحانات الوطنية", "https://azureschoolstorage.blob.core.windows.net/curriculum/bac2_math_pc.pdf", "سلسلة النجاح", "ملخص شامل للدوال وحساب التكامل والمتتاليات")
                            ),
                            lectures = listOf(
                                LectureVideo("v1", "شرح شامل: النهايات والاتصال والدوال العددية", "قناة الأستاذ نور الدين", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "45 دقيقة"),
                                LectureVideo("v2", "حساب التكامل والدوال الأصلية - مراجعة وطنية", "باك تيفي التعليمية", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "38 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "bac_2_pc_phy",
                            name = "الفيزياء والكيمياء (Physique - Chimie)",
                            iconName = "science",
                            books = listOf(
                                BookPdf("b3", "كتاب المسار في الفيزياء والكيمياء", "https://studentbooks.moe.gov.eg/", "المقرر المعتمد", "جميع وحدات الموجات والكهرباء والميكانيك"),
                                BookPdf("b4", "ملخصات الفيزياء للثانية بكالوريا PC", "https://azureschoolstorage.blob.core.windows.net/curriculum/bac2_physique_pc.pdf", "بنك الامتحانات", "ملخصات وتمارين نموذجية للامتحان الوطني")
                            ),
                            lectures = listOf(
                                LectureVideo("v3", "الموجات الميكانيكية المتوالية وشبه الدورية", "الأستاذ رشيد كيمياء وفيزياء", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "52 دقيقة"),
                                LectureVideo("v4", "ثنائي القطب RC و RL و RLC شرح مبسط", "قناة باكالوريا للجميع", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "40 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "bac_2_pc_svt",
                            name = "علوم الحياة والأرض (SVT)",
                            iconName = "eco",
                            books = listOf(
                                BookPdf("b5", "كتاب الواضح في علوم الحياة والأرض", "https://studentbooks.moe.gov.eg/", "المركز الوطني للمناهج", "استهلاك المادة العضوية وتدفق الطاقة"),
                                BookPdf("b6", "ملخص الوراثة البشرية وعلم المناعة", "https://azureschoolstorage.blob.core.windows.net/curriculum/bac2_svt_summary.pdf", "سلسلة التفوق", "رسوم بيانية وتلخيص شامل")
                            ),
                            lectures = listOf(
                                LectureVideo("v5", "استهلاك المادة العضوية وإنتاج ATP", "الدكتور سعيد للعلوم", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "35 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "bac_2_pc_philo",
                            name = "الفلسفة (Philosophie)",
                            iconName = "psychology",
                            books = listOf(
                                BookPdf("b7", "كتاب في رحاب الفلسفة - 2 باك", "https://studentbooks.moe.gov.eg/", "الوزارة", "مجزوءات الوضع البشري، المعرفة، السياسة، الأخلاق")
                            ),
                            lectures = listOf(
                                LectureVideo("v6", "منهجية تحليل نص وسؤال قولي فلسفي", "الأستاذ الفيلسوف", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "30 دقيقة")
                            )
                        )
                    )
                ),
                EducationalStream(
                    id = "bac_2_svt",
                    name = "مسلك علوم الحياة والأرض (SVT)",
                    subjects = listOf(
                        SubjectItem(
                            id = "bac_2_svt_svt",
                            name = "علوم الحياة والأرض (SVT التخصصي)",
                            iconName = "eco",
                            books = listOf(
                                BookPdf("b8", "كتاب منار علوم الحياة والأرض", "https://studentbooks.moe.gov.eg/", "وزارة التربية", "المقرر التخصصي لشعبة SVT")
                            ),
                            lectures = listOf(
                                LectureVideo("v7", "علم المناعة والظواهر الجيولوجية المصاحبة لتشكل السلاسل", "الأستاذ مصطفى", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "45 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "bac_2_svt_math",
                            name = "الرياضيات (Math)",
                            iconName = "calculate",
                            books = listOf(
                                BookPdf("b9", "المقرر الوزاري للرياضيات SVT", "https://studentbooks.moe.gov.eg/", "الوزارة", "التحليل والجبر والاحتمالات")
                            ),
                            lectures = listOf(
                                LectureVideo("v8", "شرح الاحتمالات والمتغير العشوائي", "باك أكاديمي", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "33 دقيقة")
                            )
                        )
                    )
                ),
                EducationalStream(
                    id = "bac_2_sm",
                    name = "مسلك العلوم الرياضية أ و ب (Sciences Maths)",
                    subjects = listOf(
                        SubjectItem(
                            id = "bac_2_sm_math",
                            name = "الرياضيات التخصصية المتقدمة",
                            iconName = "functions",
                            books = listOf(
                                BookPdf("b10", "كتاب النجاح في الرياضيات - علوم رياضية", "https://studentbooks.moe.gov.eg/", "المقرر الرسمي", "الحسابيات، البنيات الجبرية، الفضاءات المتجهية")
                            ),
                            lectures = listOf(
                                LectureVideo("v9", "الحسابيات في Z وقابلية القسمة", "أستاذ الرياضيات المتقدمة", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "50 دقيقة")
                            )
                        )
                    )
                ),
                EducationalStream(
                    id = "bac_2_lettres",
                    name = "مسلك الآداب والعلوم الإنسانية",
                    subjects = listOf(
                        SubjectItem(
                            id = "bac_2_lettres_ar",
                            name = "اللغة العربية وآدابها",
                            iconName = "menu_book",
                            books = listOf(
                                BookPdf("b11", "كتاب الرائد في اللغة العربية", "https://studentbooks.moe.gov.eg/", "المقرر الرسمي", "إحياء النموذج، تكسير البنية، تجديد الرؤيا")
                            ),
                            lectures = listOf(
                                LectureVideo("v10", "مناهج النقد الحديث ومؤلف ظاهرة الشعر الحديث", "أستاذ الأدب العربي", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "40 دقيقة")
                            )
                        )
                    )
                )
            )
        ),
        EducationalGrade(
            id = "bac_1",
            name = "أولى بكالوريا (1ère Bac)",
            stage = StageType.BACCALAUREATE,
            streams = listOf(
                EducationalStream(
                    id = "bac_1_sci",
                    name = "شعبة العلوم التجريبية والرياضية",
                    subjects = listOf(
                        SubjectItem(
                            id = "bac_1_sci_fr",
                            name = "اللغة الفرنسية والروايات المقررة",
                            iconName = "language",
                            books = listOf(
                                BookPdf("b12", "روايات الامتحان الجهوي (Antigone, La Boîte à Merveilles, Le Dernier Jour d'un Condamné)", "https://studentbooks.moe.gov.eg/", "الروايات المعتمدة", "تحليل شامل للشخصيات والفصول")
                            ),
                            lectures = listOf(
                                LectureVideo("v11", "Résumé complet: La Boîte à Merveilles", "Professeur Français Bac", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "35 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "bac_1_sci_islamic",
                            name = "التربية الإسلامية للجهوي",
                            iconName = "auto_stories",
                            books = listOf(
                                BookPdf("b13", "كتاب منار التربية الإسلامية - أولى باك", "https://studentbooks.moe.gov.eg/", "وزارة التربية", "سورة يوسف والمداخل الخمسة")
                            ),
                            lectures = listOf(
                                LectureVideo("v12", "حفظ وتفسير سورة يوسف للجهوي", "التربية الإسلامية المبسطة", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "25 دقيقة")
                            )
                        )
                    )
                )
            )
        ),
        EducationalGrade(
            id = "sec_3",
            name = "الصف الثالث الثانوي (تالتة ثانوي عامة)",
            stage = StageType.SECONDARY,
            streams = listOf(
                EducationalStream(
                    id = "sec_3_science",
                    name = "شعبة علمي علوم",
                    subjects = listOf(
                        SubjectItem(
                            id = "sec_3_bio",
                            name = "الأحياء والجيولوجيا",
                            iconName = "biotech",
                            books = listOf(
                                BookPdf("b14", "كتاب الوزارة المدرسي - الأحياء للصف الثالث الثانوي", "https://studentbooks.moe.gov.eg/", "وزارة التربية والتعليم المصرية", "الدعامة والحركة، التنسيق الهرموني، التكاثر، المناعة، البيولوجيا الجزيئية DNA"),
                                BookPdf("b15", "كتيب المفاهيم والنماذج الاسترشادية للأحياء", "https://azureschoolstorage.blob.core.windows.net/curriculum/sec3_biology_concepts.pdf", "بنك المعرفة المصري", "كتيب المفاهيم المعتمد في لجان الامتحان")
                            ),
                            lectures = listOf(
                                LectureVideo("v13", "المراجعة النهائية: الدعامة والحركة والهرمونات", "د. محمد أيمن", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "60 دقيقة"),
                                LectureVideo("v14", "شرح البيولوجيا الجزيئية و DNA من الصفر", "قناة مدرستنا 3", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "45 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "sec_3_chem",
                            name = "الكيمياء",
                            iconName = "science",
                            books = listOf(
                                BookPdf("b16", "كتاب الكيمياء المعتمد - تالتة ثانوي", "https://studentbooks.moe.gov.eg/", "وزارة التربية والتعليم", "العناصر الانتقالية، التحليل الكيميائي، الاتزان، الكهربية، الكيمياء العضوية"),
                                BookPdf("b17", "ملخص الكيمياء العضوية الشامل", "https://azureschoolstorage.blob.core.windows.net/curriculum/sec3_chemistry_organic.pdf", "منصة نجوى والوزارة", "تفاعلات الهيدروكربونات ومشتقاتها")
                            ),
                            lectures = listOf(
                                LectureVideo("v15", "الكيمياء العضوية كاملة في كبسولة", "مستر عبد الجواد", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "55 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "sec_3_phy",
                            name = "الفيزياء الحديثة والكلاسيكية",
                            iconName = "bolt",
                            books = listOf(
                                BookPdf("b18", "كتاب الفيزياء - الصف الثالث الثانوي", "https://studentbooks.moe.gov.eg/", "الوزارة", "الكهربية المغناطيسية وأجهزة القياس والفيزياء الحديثة"),
                                BookPdf("b19", "بنك أسئلة الفيزياء والنماذج الوزارية", "https://azureschoolstorage.blob.core.windows.net/curriculum/sec3_physics_bank.pdf", "منصة حصص مصر", "تدريبات على نمط البابل شيت")
                            ),
                            lectures = listOf(
                                LectureVideo("v16", "الفصل الأول: التيار الكهربي وقانون كيرشوف", "مستر حسام خليل", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "50 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "sec_3_ar",
                            name = "اللغة العربية والنحو والبلاغة",
                            iconName = "menu_book",
                            books = listOf(
                                BookPdf("b20", "كتاب اللغة العربية - النصوص والقراءة والنحو", "https://studentbooks.moe.gov.eg/", "الوزارة", "الوحدات النحوية السبع وفنون الأدب والبلاغة")
                            ),
                            lectures = listOf(
                                LectureVideo("v17", "مراجعة قواعد النحو كاملة لليلة الامتحان", "مستر رضا الفاروق", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "75 دقيقة")
                            )
                        )
                    )
                ),
                EducationalStream(
                    id = "sec_3_math",
                    name = "شعبة علمي رياضة",
                    subjects = listOf(
                        SubjectItem(
                            id = "sec_3_math_pure",
                            name = "الرياضيات البحتة (تفاضل وتكامل وجبر وهندسة فراغية)",
                            iconName = "calculate",
                            books = listOf(
                                BookPdf("b21", "كتاب التفاضل والتكامل للصف الثالث الثانوي", "https://studentbooks.moe.gov.eg/", "وزارة التربية والتعليم", "اشتقاق الدوال المثلثية وتطبيقات القيم العظمى")
                            ),
                            lectures = listOf(
                                LectureVideo("v18", "التفاضل والتكامل وحساب الحجوم الدورانية", "الرياضيات مع الخبير", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "55 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "sec_3_math_applied",
                            name = "الرياضيات التطبيقية (استاتيكا وديناميكا)",
                            iconName = "precision_manufacturing",
                            books = listOf(
                                BookPdf("b22", "كتاب الاستاتيكا والديناميكا", "https://studentbooks.moe.gov.eg/", "الوزارة", "الاحتكاك، العزوم، الاتزان العام، قوانين نيوتن")
                            ),
                            lectures = listOf(
                                LectureVideo("v19", "الاحتكاك والعزوم وتطبيقات القوى المتوازية", "مدرستنا الثانوية", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "40 دقيقة")
                            )
                        )
                    )
                ),
                EducationalStream(
                    id = "sec_3_arts",
                    name = "الشعبة الأدبية",
                    subjects = listOf(
                        SubjectItem(
                            id = "sec_3_history",
                            name = "التاريخ",
                            iconName = "history_edu",
                            books = listOf(
                                BookPdf("b23", "كتاب التاريخ للصف الثالث الثانوي", "https://studentbooks.moe.gov.eg/", "الوزارة", "تاريخ مصر والعرب الحديث والمعاصر")
                            ),
                            lectures = listOf(
                                LectureVideo("v20", "الفصل الأول: الحملة الفرنسية على مصر والشام", "الخطة التعليمية", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "42 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "sec_3_geo",
                            name = "الجغرافيا السياسية",
                            iconName = "public",
                            books = listOf(
                                BookPdf("b24", "كتاب الجغرافيا السياسية", "https://studentbooks.moe.gov.eg/", "الوزارة", "الدولة وأنواعها، الحدود السياسية، التكتلات الاقتصادية")
                            ),
                            lectures = listOf(
                                LectureVideo("v21", "مدخل لدراسة الجغرافيا السياسية", "مستر أحمد سيف", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "36 دقيقة")
                            )
                        )
                    )
                )
            )
        ),
        EducationalGrade(
            id = "sec_2",
            name = "الصف الثاني الثانوي (تانية ثانوي)",
            stage = StageType.SECONDARY,
            streams = listOf(
                EducationalStream(
                    id = "sec_2_general",
                    name = "القسم العلمي والأدبي المشترك",
                    subjects = listOf(
                        SubjectItem(
                            id = "sec_2_math",
                            name = "الرياضيات العامة وتطبيقاتها",
                            iconName = "calculate",
                            books = listOf(
                                BookPdf("b25", "كتاب الرياضيات للصف الثاني الثانوي", "https://studentbooks.moe.gov.eg/", "الوزارة", "الجبر والتفاضل وحساب المثلثات")
                            ),
                            lectures = listOf(
                                LectureVideo("v22", "الدوال الحقيقية وتحديد المجال والمدى", "دروس أونلاين ثانوية", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "30 دقيقة")
                            )
                        ),
                        SubjectItem(
                            id = "sec_2_en",
                            name = "اللغة الإنجليزية (English Language)",
                            iconName = "translate",
                            books = listOf(
                                BookPdf("b26", "كتاب New Hello - الصف الثاني الثانوي", "https://studentbooks.moe.gov.eg/", "الوزارة", "المنهج الرسمي مع القصة المقررة")
                            ),
                            lectures = listOf(
                                LectureVideo("v23", "Unit 1: Grammar & Vocabulary Breakdown", "Mr. Amr English", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "32 دقيقة")
                            )
                        )
                    )
                )
            )
        ),
        EducationalGrade(
            id = "sec_1",
            name = "الصف الأول الثانوي (أولى ثانوي)",
            stage = StageType.SECONDARY,
            streams = listOf(
                EducationalStream(
                    id = "sec_1_general",
                    name = "الصف الأول الثانوي العام",
                    subjects = listOf(
                        SubjectItem(
                            id = "sec_1_all",
                            name = "المناهج والكتب المقررة المعتمدة",
                            iconName = "library_books",
                            books = listOf(
                                BookPdf("b27", "جميع كتب الصف الأول الثانوي التفاعلية", "https://studentbooks.moe.gov.eg/", "بوابة المناهج الرسمية", "الكتب والأنشطة الرقمية للتابلت المدرسي"),
                                BookPdf("b28", "دليل الاختبارات الإلكترونية وبنك الأسئلة", "https://azureschoolstorage.blob.core.windows.net/curriculum/sec1_guide.pdf", "الوزارة", "نماذج الامتحانات التدريبية")
                            ),
                            lectures = listOf(
                                LectureVideo("v24", "شرح عام ومراجعة شاملة لمناهج أولى ثانوي", "قناة مدرستنا 1", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ", "40 دقيقة")
                            )
                        )
                    )
                )
            )
        )
    )

    val motivationalQuotes: List<MotivationalQuote> = listOf(
        MotivationalQuote(1, "النجاح لا يأتي بالصدفة، بل هو ثمرة التعب والاستمرار والتضحية والتوكل على الله."),
        MotivationalQuote(2, "ما تزرعه اليوم في ساعات السهر والمذاكرة، ستحصده غداً فرحة ونجاحاً يرفع رأسك وأهلك."),
        MotivationalQuote(3, "تذكر دائماً أنك لست وحدك، فالله يرى سعيك ولن يضيع أجرك أبداً."),
        MotivationalQuote(4, "كل دقيقة تركز فيها الآن تقربك خطوة حقيقية نحو حلمك الذي تستحقه."),
        MotivationalQuote(5, "لا توجد مصاعد تصعد بك للقمة، عليك أن تأخذ السلالم خطوة بخطوة بكل عزم."),
        MotivationalQuote(6, "الفرق بين من نجح ومن استسلم ليس الذكاء، بل الصبر والإصرار في اللحظات الصعبة."),
        MotivationalQuote(7, "أنت أقوى مما تعتقد، وكل درس تنهيه اليوم هو انتصار عظيم."),
        MotivationalQuote(8, "وقل ربي زدني علماً.. توكل على الله وافتح صفحة جديدة بكل همة وتفاؤل.")
    )

    val dailyAzkarList: List<DailyZikr> = listOf(
        DailyZikr(1, "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ", "كلمتان خفيفتان على اللسان ثقيلتان في الميزان حبيبتان إلى الرحمن", 33),
        DailyZikr(2, "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ", "كنز من كنوز الجنة وتفريج للهموم والكروب", 33),
        DailyZikr(3, "اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ", "من صلى عليّ صلاة صلى الله عليه بها عشراً", 10),
        DailyZikr(4, "لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ", "دعوة ذي النون ما دعا بها مسلم في كرب إلا فرج الله عنه", 33),
        DailyZikr(5, "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ", "مغفرة للذنوب وتيسير للأرزاق وراحة للقلب", 33),
        DailyZikr(6, "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْماً نَافِعاً، وَرِزْقاً طَيِّباً، وَعَمَلاً مُتَقَبَّلاً", "دعاء الصباح والبركة في العلم والعمل", 3)
    )

    val adhkarContent: List<AdhkarItem> = listOf(
        // أذكار الصباح
        AdhkarItem(101, AdhkarCategory.MORNING, "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", 1, "بركة الصباح وحفظ اليوم"),
        AdhkarItem(102, AdhkarCategory.MORNING, "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.", 1, "حفظ وتوكل على الحي القيوم"),
        AdhkarItem(103, AdhkarCategory.MORNING, "سَيِّدُ الاِسْتِغْفَارِ: اللَّهُمَّ أَنْتَ رَبِّي لاَ إِلَهَ إِلاَّ أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لاَ يَغْفِرُ الذُّنُوبَ إِلاَّ أَنْتَ.", 1, "من قالها موقناً بها ومات دخل الجنة"),
        AdhkarItem(104, AdhkarCategory.MORNING, "بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ العَلِيمُ.", 3, "لم يضره شيء حتى يمسي"),
        AdhkarItem(105, AdhkarCategory.MORNING, "حَسْبِيَ اللَّهُ لاَ إِلَهَ إِلاَّ هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ.", 7, "كفاه الله ما أهمه من أمر دنياه وآخرته"),

        // أذكار المساء
        AdhkarItem(201, AdhkarCategory.EVENING, "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", 1, "حفظ الليل والسكينة"),
        AdhkarItem(202, AdhkarCategory.EVENING, "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.", 3, "لم يضره شيء في تلك الليلة"),
        AdhkarItem(203, AdhkarCategory.EVENING, "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لاَ إِلَهَ إِلاَّ أَنْتَ.", 3, "صحة العافية والبدن"),

        // أذكار النوم
        AdhkarItem(301, AdhkarCategory.SLEEP, "بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ.", 1, "أمان ونوم هانئ"),
        AdhkarItem(302, AdhkarCategory.SLEEP, "قراءة آية الكرسي: {اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ...}", 1, "لا يزال عليك من الله حافظ حتى تصبح"),
        AdhkarItem(303, AdhkarCategory.SLEEP, "سُبْحَانَ اللَّهِ (33)، وَالْحَمْدُ لِلَّهِ (33)، وَاللَّهُ أَكْبَرُ (34).", 1, "خير للمسلم من خادم وقوة للبدن في اليوم التالي"),

        // أدعية المذاكرة والامتحانات
        AdhkarItem(401, AdhkarCategory.STUDY, "دعاء قبل البدء في المذاكرة: اللَّهُمَّ إِنِّي أَسْأَلُكَ فَهْمَ النَّبِيِّينَ، وَحِفْظَ الْمُرْسَلِينَ، وَالْمَلاَئِكَةِ الْمُقَرَّبِينَ. اللَّهُمَّ اجْعَلْ أَلْسِنَتَنَا عَامِرَةً بِذِكْرِكَ، وَقُلُوبَنَا بِخَشْيَتِكَ، وَأَسْرَارَنَا بِطَاعَتِكَ، إِنَّكَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", 1, "تيسير الفهم وقوة الحفظ"),
        AdhkarItem(402, AdhkarCategory.STUDY, "دعاء تيسير الصعب: اللَّهُمَّ لاَ سَهْلَ إِلاَّ مَا جَعَلْتَهُ سَهْلاً، وَأَنْتَ تَجْعَلُ الْحَزْنَ إِذَا شِئْتَ سَهْلاً.", 3, "عند مواجهة مسألة معقدة أو درس صعب"),
        AdhkarItem(403, AdhkarCategory.STUDY, "دعاء النسيان وتذكر الإجابة: اللَّهُمَّ يَا جَامِعَ النَّاسِ لِيَوْمٍ لاَ رَيْبَ فِيهِ، اجْمَعْ عَلَيَّ ضَالَّتِي وَرُدَّ إِلَيَّ مَا حَفِظْتُهُ وَمَا فَهِمْتُهُ عِنْدَ حَاجَتِي إِلَيْهِ.", 1, "عند النسيان في قاعة الامتحان"),
        AdhkarItem(404, AdhkarCategory.STUDY, "دعاء بعد الانتهاء من المذاكرة: اللَّهُمَّ إِنِّي أَسْتَوْدِعُكَ مَا قَرَأْتُ وَمَا حَفِظْتُ وَمَا تَعَلَّمْتُ، فَرُدَّهُ إِلَيَّ عِنْدَ حَاجَتِي إِلَيْهِ، وَلاَ تُنْسِنِيهِ يَا رَبَّ الْعَالَمِينَ.", 1, "تثبيت العلم في الذاكرة")
    )
}
