package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "prayer_records")
data class PrayerRecordEntity(
    @PrimaryKey val date: String, // "YYYY-MM-DD"
    val fajr: Boolean = false,
    val dhuhr: Boolean = false,
    val asr: Boolean = false,
    val maghrib: Boolean = false,
    val isha: Boolean = false
) {
    val completedCount: Int
        get() = (if (fajr) 1 else 0) +
                (if (dhuhr) 1 else 0) +
                (if (asr) 1 else 0) +
                (if (maghrib) 1 else 0) +
                (if (isha) 1 else 0)

    val isAllCompleted: Boolean
        get() = completedCount == 5
}
