package com.example.data.model

data class EducationalGrade(
    val id: String,
    val name: String,
    val stage: StageType,
    val streams: List<EducationalStream>
)

enum class StageType {
    BACCALAUREATE, // بكالوريا
    SECONDARY // ثانوية عامة
}

data class EducationalStream(
    val id: String,
    val name: String,
    val subjects: List<SubjectItem>
)

data class SubjectItem(
    val id: String,
    val name: String,
    val iconName: String,
    val books: List<BookPdf>,
    val lectures: List<LectureVideo>
)

data class BookPdf(
    val id: String,
    val title: String,
    val pdfUrl: String,
    val source: String = "وزارة التربية والتعليم",
    val description: String = ""
)

data class LectureVideo(
    val id: String,
    val title: String,
    val channelName: String,
    val videoUrl: String,
    val youtubeId: String = "",
    val duration: String = ""
)

data class MotivationalQuote(
    val id: Int,
    val quote: String,
    val author: String = "حكمة وتفاؤل"
)

data class DailyZikr(
    val id: Int,
    val text: String,
    val reward: String,
    val targetCount: Int = 33
)

data class AdhkarItem(
    val id: Int,
    val category: AdhkarCategory,
    val text: String,
    val count: Int,
    val benefit: String = ""
)

enum class AdhkarCategory {
    MORNING, // أذكار الصباح
    EVENING, // أذكار المساء
    SLEEP,   // أذكار النوم
    STUDY    // أدعية المذاكرة والامتحانات
}

data class PrayerTiming(
    val fajr: String = "04:35",
    val sunrise: String = "05:58",
    val dhuhr: String = "12:05",
    val asr: String = "15:35",
    val maghrib: String = "18:12",
    val isha: String = "19:30",
    val dateReadable: String = "",
    val hijriDate: String = ""
)

data class NextPrayerInfo(
    val name: String,
    val arabicName: String,
    val time: String,
    val remainingMillis: Long
)

data class Surah(
    val number: Int,
    val name: String,
    val englishName: String,
    val englishNameTranslation: String,
    val numberOfAyahs: Int,
    val revelationType: String
)

data class Ayah(
    val number: Int,
    val text: String,
    val numberInSurah: Int,
    val audioUrl: String = ""
)

data class QuranReciter(
    val id: String,
    val name: String,
    val subName: String,
    val mp3ServerPrefix: String
)
