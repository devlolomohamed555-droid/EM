package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.LessonEntity
import com.example.ui.viewmodels.MainViewModel
import com.example.utils.TimeUtils
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(
    viewModel: MainViewModel
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val lessons by viewModel.allLessons.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedDayFilter by remember { mutableStateOf(0) } // 0 = all days

    // Auto-request notification permission on Android 13+
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { /* result handled */ }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            val permissionStatus = androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionStatus != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val daysList = listOf(
        Pair(0, "جميع الأيام"),
        Pair(Calendar.SUNDAY, "الأحد"),
        Pair(Calendar.MONDAY, "الاثنين"),
        Pair(Calendar.TUESDAY, "الثلاثاء"),
        Pair(Calendar.WEDNESDAY, "الأربعاء"),
        Pair(Calendar.THURSDAY, "الخميس"),
        Pair(Calendar.FRIDAY, "الجمعة"),
        Pair(Calendar.SATURDAY, "السبت")
    )

    val filteredLessons = if (selectedDayFilter == 0) {
        lessons
    } else {
        lessons.filter { it.dayOfWeek == selectedDayFilter }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_lesson_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة درس أو حصة")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مواعيد دروسي ومحاضراتي",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "تنبيهات تلقائية لطيفة قبل بدء كل حصة ومحاضرة",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                FilledTonalButton(
                    onClick = {
                        viewModel.sendGentleStudyReminderTest()
                    }
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تجربة تنبيه", fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Gentle Push Reminders Status Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AlarmOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "التنبيهات اللطيفة مجدولة تلقائياً 🔔",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            val activeCount = lessons.count { it.isEnabled }
                            Text(
                                text = "مفعل تذكيرات مسبقة لـ $activeCount جلسة ومحاضرة قادمة",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Day Filter Chips
            ScrollableTabRow(
                selectedTabIndex = selectedDayFilter,
                edgePadding = 0.dp,
                divider = {}
            ) {
                daysList.forEach { (dayId, dayName) ->
                    Tab(
                        selected = selectedDayFilter == dayId,
                        onClick = { selectedDayFilter = dayId },
                        text = { Text(dayName, fontSize = 13.sp, fontWeight = if (selectedDayFilter == dayId) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredLessons.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد مواعيد مضافة في هذا اليوم",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "اضغط على زر (+) لإضافة أول موعد لدرس أو محاضرة",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredLessons, key = { it.id }) { lesson ->
                        LessonItemCard(
                            lesson = lesson,
                            onToggleEnabled = { viewModel.toggleLessonEnabled(lesson) },
                            onDelete = { viewModel.deleteLesson(lesson.id) }
                        )
                    }
                }
            }
        }
    }

    // Add Lesson Dialog
    if (showAddDialog) {
        AddLessonDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { title, subject, teacher, dayOfWeek, start, end, room, reminder ->
                viewModel.addLesson(title, subject, teacher, dayOfWeek, start, end, room, reminder)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun LessonItemCard(
    lesson: LessonEntity,
    onToggleEnabled: () -> Unit,
    onDelete: () -> Unit
) {
    val isEnabled = lesson.isEnabled
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isEnabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = TimeUtils.getArabicDayName(lesson.dayOfWeek),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isEnabled) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = lesson.subject,
                        fontSize = 13.sp,
                        color = if (isEnabled) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = lesson.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                )

                if (lesson.teacher.isNotBlank()) {
                    Text(
                        text = "المدرس: ${lesson.teacher}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${lesson.startTime} - ${lesson.endTime}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline
                    )

                    Spacer(modifier = Modifier.width(12.dp))
                    Icon(
                        imageVector = if (isEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                        contentDescription = null,
                        tint = if (isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isEnabled) "تنبيه قبل ${lesson.reminderMinutesBefore} دقيقة" else "التنبيه متوقف",
                        fontSize = 11.sp,
                        color = if (isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { onToggleEnabled() },
                    modifier = Modifier.padding(end = 4.dp)
                )

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف الموعد",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

@Composable
fun AddLessonDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, Int, String, String, String, Int) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("الرياضيات") }
    var teacher by remember { mutableStateOf("") }
    var selectedDay by remember { mutableStateOf(Calendar.SUNDAY) }
    var startTime by remember { mutableStateOf("16:00") }
    var endTime by remember { mutableStateOf("18:00") }
    var reminderMinutes by remember { mutableStateOf(15) }

    val days = listOf(
        Pair(Calendar.SUNDAY, "الأحد"),
        Pair(Calendar.MONDAY, "الاثنين"),
        Pair(Calendar.TUESDAY, "الثلاثاء"),
        Pair(Calendar.WEDNESDAY, "الأربعاء"),
        Pair(Calendar.THURSDAY, "الخميس"),
        Pair(Calendar.FRIDAY, "الجمعة"),
        Pair(Calendar.SATURDAY, "السبت")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة موعد درس أو محاضرة", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الدرس أو الفصل") },
                    placeholder = { Text("مثال: التفاضل والتكامل، الموجات، النحو") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("المادة الدراسية") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = teacher,
                    onValueChange = { teacher = it },
                    label = { Text("اسم المدرس أو المكان (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("اختر يوم الأسبوع:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    days.take(4).forEach { (dayVal, dayLabel) ->
                        FilterChip(
                            selected = selectedDay == dayVal,
                            onClick = { selectedDay = dayVal },
                            label = { Text(dayLabel, fontSize = 11.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    days.drop(4).forEach { (dayVal, dayLabel) ->
                        FilterChip(
                            selected = selectedDay == dayVal,
                            onClick = { selectedDay = dayVal },
                            label = { Text(dayLabel, fontSize = 11.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("البدء (HH:mm)") },
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("الانتهاء") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("وقت التنبيه التلقائي قبل الدرس:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(10, 15, 30, 60).forEach { mins ->
                        FilterChip(
                            selected = reminderMinutes == mins,
                            onClick = { reminderMinutes = mins },
                            label = { Text("$mins دقيقة") }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalTitle = title.ifBlank { "درس $subject" }
                    onConfirm(finalTitle, subject, teacher, selectedDay, startTime, endTime, "", reminderMinutes)
                },
                enabled = subject.isNotBlank()
            ) {
                Text("حفظ الموعد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
