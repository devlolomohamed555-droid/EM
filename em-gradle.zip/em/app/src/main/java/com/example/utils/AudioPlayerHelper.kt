package com.example.utils

import android.media.AudioAttributes
import android.media.MediaPlayer
import com.example.data.model.QuranReciter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

object AudioPlayerHelper {

    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private var progressJob: Job? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _currentPlayingUrl = MutableStateFlow<String?>(null)
    val currentPlayingUrl: StateFlow<String?> = _currentPlayingUrl

    private val _currentTitle = MutableStateFlow("")
    val currentTitle: StateFlow<String> = _currentTitle

    private val _currentSurahNumber = MutableStateFlow<Int?>(null)
    val currentSurahNumber: StateFlow<Int?> = _currentSurahNumber

    private val _currentPositionMs = MutableStateFlow(0)
    val currentPositionMs: StateFlow<Int> = _currentPositionMs

    private val _durationMs = MutableStateFlow(0)
    val durationMs: StateFlow<Int> = _durationMs

    val defaultReciters = listOf(
        QuranReciter("afs", "مشاري راشد العفاسي", "حفص عن عاصم", "https://server8.mp3quran.net/afs/"),
        QuranReciter("basit", "عبد الباسط عبد الصمد", "المصحف المرتل", "https://server7.mp3quran.net/basit/"),
        QuranReciter("maher", "ماهر المعيقلي", "حفص عن عاصم", "https://server12.mp3quran.net/maher/"),
        QuranReciter("husr", "محمود خليل الحصري", "مرتل برواية حفص", "https://server13.mp3quran.net/husr/"),
        QuranReciter("minsh", "محمد صديق المنشاوي", "المصحف المرتل", "https://server10.mp3quran.net/minsh/"),
        QuranReciter("ajm", "أحمد بن علي العجمي", "حفص عن عاصم", "https://server10.mp3quran.net/ajm/"),
        QuranReciter("s_gmd", "سعد الغامدي", "حفص عن عاصم", "https://server7.mp3quran.net/s_gmd/")
    )

    private val _selectedReciter = MutableStateFlow(defaultReciters[0])
    val selectedReciter: StateFlow<QuranReciter> = _selectedReciter

    fun setReciter(reciter: QuranReciter) {
        _selectedReciter.value = reciter
    }

    fun getSurahAudioUrl(surahNumber: Int, reciter: QuranReciter = _selectedReciter.value): String {
        val formattedNumber = String.format("%03d", surahNumber)
        return "${reciter.mp3ServerPrefix}$formattedNumber.mp3"
    }

    fun playSurah(surahNumber: Int, surahName: String, reciter: QuranReciter = _selectedReciter.value) {
        val url = getSurahAudioUrl(surahNumber, reciter)
        val title = "$surahName • بصوت الشيخ ${reciter.name}"
        _currentSurahNumber.value = surahNumber
        playAudio(url, title)
    }

    fun playAudio(url: String, title: String = "تلاوة قرآنية مباركة", onCompletion: () -> Unit = {}) {
        if (url.isBlank()) return

        if (_currentPlayingUrl.value == url && mediaPlayer != null) {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.pause()
                _isPlaying.value = false
            } else {
                mediaPlayer?.start()
                _isPlaying.value = true
                startProgressTracker()
            }
            return
        }

        stopAudio()
        _isLoading.value = true
        _currentTitle.value = title

        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener { mp ->
                    _isLoading.value = false
                    _durationMs.value = mp.duration
                    mp.start()
                    _isPlaying.value = true
                    _currentPlayingUrl.value = url
                    startProgressTracker()
                }
                setOnCompletionListener {
                    _isPlaying.value = false
                    _currentPlayingUrl.value = null
                    _currentPositionMs.value = 0
                    stopProgressTracker()
                    onCompletion()
                }
                setOnErrorListener { _, _, _ ->
                    _isLoading.value = false
                    _isPlaying.value = false
                    _currentPlayingUrl.value = null
                    stopProgressTracker()
                    false
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _isLoading.value = false
            _isPlaying.value = false
            _currentPlayingUrl.value = null
        }
    }

    private fun startProgressTracker() {
        stopProgressTracker()
        progressJob = scope.launch {
            while (_isPlaying.value && mediaPlayer != null) {
                try {
                    _currentPositionMs.value = mediaPlayer?.currentPosition ?: 0
                } catch (e: Exception) {
                    // Ignore transient exceptions
                }
                delay(500L)
            }
        }
    }

    private fun stopProgressTracker() {
        progressJob?.cancel()
        progressJob = null
    }

    fun togglePlayPause() {
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.pause()
                    _isPlaying.value = false
                    stopProgressTracker()
                } else {
                    mediaPlayer?.start()
                    _isPlaying.value = true
                    startProgressTracker()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun seekTo(positionMs: Int) {
        try {
            mediaPlayer?.seekTo(positionMs)
            _currentPositionMs.value = positionMs
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun forward10Seconds() {
        try {
            val current = mediaPlayer?.currentPosition ?: 0
            val target = (current + 10000).coerceAtMost(mediaPlayer?.duration ?: 0)
            seekTo(target)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun rewind10Seconds() {
        try {
            val current = mediaPlayer?.currentPosition ?: 0
            val target = (current - 10000).coerceAtLeast(0)
            seekTo(target)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopAudio() {
        stopProgressTracker()
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                }
                mediaPlayer?.release()
                mediaPlayer = null
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        _isPlaying.value = false
        _isLoading.value = false
        _currentPlayingUrl.value = null
        _currentPositionMs.value = 0
        _durationMs.value = 0
    }
}
