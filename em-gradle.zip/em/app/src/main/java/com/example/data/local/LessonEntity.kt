package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val teacher: String = "",
    val dayOfWeek: Int, // 1: Sunday, 2: Monday, ..., 7: Saturday
    val startTime: String, // HH:mm format, e.g., "09:30"
    val endTime: String, // HH:mm format, e.g., "11:00"
    val locationOrRoom: String = "",
    val reminderMinutesBefore: Int = 15,
    val isEnabled: Boolean = true
)
