package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.ui.viewmodels.MainViewModel
import com.example.utils.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PomodoroStudyScreen(
    viewModel: MainViewModel,
    onNavigateToSchedule: () -> Unit
) {
    val pomodoroSeconds by viewModel.pomodoroSecondsRemaining.collectAsStateWithLifecycle()
    val isRunning by viewModel.isPomodoroRunning.collectAsStateWithLifecycle()
    val isFocusPhase by viewModel.isFocusPhase.collectAsStateWithLifecycle()
    val ambianceIndex by viewModel.pomodoroAmbianceIndex.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    var isFullscreenMode by remember { mutableStateOf(false) }
    var showCustomSettingsDialog by remember { mutableStateOf(false) }

    // When running, the user can also manually toggle fullscreen or it can activate
    val currentFocusMinutes = userProfile?.pomodoroFocusMinutes ?: 25
    val currentBreakMinutes = userProfile?.pomodoroBreakMinutes ?: 5

    // Color themes for ambiance
    val ambianceColors = listOf(
        Pair("كحلي ليلي", AmbianceMidnight),
        Pair("أخضر هادئ (Sage)", AmbianceSage),
        Pair("وردي ناعم", Color(0xFFE29595)), // As seen in screenshot Page 4 (soft blush peach/rose)
        Pair("أزرق عميق", AmbianceDeepIndigo),
        Pair("خشبي دافئ", AmbianceWarmWood)
    )

    val currentAmbianceColor = ambianceColors.getOrElse(ambianceIndex) { ambianceColors[0] }.second

    if (isFullscreenMode) {
        // FULLSCREEN IMMERSIVE STUDY SESSION (Page 4)
        FullscreenPomodoroView(
            secondsRemaining = pomodoroSeconds,
            isRunning = isRunning,
            isFocusPhase = isFocusPhase,
            ambianceColor = currentAmbianceColor,
            ambianceOptions = ambianceColors,
            currentAmbianceIndex = ambianceIndex,
            onSelectAmbiance = { viewModel.setAmbianceTheme(it) },
            onStartPause = {
                if (isRunning) viewModel.pausePomodoro() else viewModel.startPomodoro()
            },
            onReset = { viewModel.resetPomodoro() },
            onExitFullscreen = { isFullscreenMode = false }
        )
    } else {
        // STANDARD DASHBOARD STUDY VIEW
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "جلسة الدراسة (Pomodoro)",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "نظم وقتك وعزز تركيزك الذهني بدون تشتت",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                IconButton(onClick = { showCustomSettingsDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "تخصيص الوقت",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Study Session Main Box (matches Page 4 screenshot layout)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .shadow(8.dp, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = currentAmbianceColor
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Top controls inside card
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.Black.copy(alpha = 0.25f)
                        ) {
                            Text(
                                text = if (isFocusPhase) "جلسة تركيز 🧠" else "وقت الاستراحة ☕",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        // Fullscreen button
                        IconButton(
                            onClick = { isFullscreenMode = true },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.25f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fullscreen,
                                contentDescription = "ملء الشاشة",
                                tint = Color.White
                            )
                        }
                    }

                    // Large Digital Countdown Timer
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = TimeUtils.formatMinutesSeconds(pomodoroSeconds),
                            fontSize = 68.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 4.sp
                        )

                        Text(
                            text = if (isRunning) "المؤقت يعمل.. بالتوفيق!" else "المؤقت متوقف مؤقتاً",
                            fontSize = 14.sp,
                            color = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    // Bottom Action Button (Page 4: "بدء الجلسة / إنهاء الجلسة")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                if (isRunning) {
                                    viewModel.pausePomodoro()
                                } else {
                                    viewModel.startPomodoro()
                                    isFullscreenMode = true // Enter fullscreen on start as requested!
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp)
                                .testTag("pomodoro_start_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color(0xFF1E293B)
                            )
                        ) {
                            Icon(
                                imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF1E293B)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isRunning) "إيقاف مؤقت" else "بدء الجلسة (ملء الشاشة)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(
                            onClick = { viewModel.resetPomodoro() },
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.2f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Replay,
                                contentDescription = "إعادة ضبط",
                                tint = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Ambiance Background Color Selector (Page 4: "اضف زر لتغيير لون الخلفية")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "تغيير لون خلفية الجلسة (أجواء مريحة للعين):",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ambianceColors.forEachIndexed { index, (name, color) ->
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (ambianceIndex == index) 3.dp else 1.dp,
                                        color = if (ambianceIndex == index) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable { viewModel.setAmbianceTheme(index) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (ambianceIndex == index) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = name,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Presets & Link to Lesson schedule
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToSchedule() },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "جدول مواعيد الدروس والحصص",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = "ضبط التنبيهات الذكية قبل الموعد",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "فتح الجدول",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }

    // Custom Timer Settings Dialog
    if (showCustomSettingsDialog) {
        var focusInput by remember { mutableStateOf(currentFocusMinutes.toString()) }
        var breakInput by remember { mutableStateOf(currentBreakMinutes.toString()) }

        AlertDialog(
            onDismissRequest = { showCustomSettingsDialog = false },
            title = {
                Text(
                    text = "تخصيص أوقات الدراسة والراحة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "الافتراضي الموصى به: 25 دقيقة مذاكرة و 5 دقائق راحة.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.outline
                    )

                    OutlinedTextField(
                        value = focusInput,
                        onValueChange = { focusInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("مدة التركيز (بالدقائق)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = breakInput,
                        onValueChange = { breakInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("مدة الاستراحة (بالدقائق)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val f = focusInput.toIntOrNull() ?: 25
                        val b = breakInput.toIntOrNull() ?: 5
                        viewModel.setPomodoroCustomMinutes(f.coerceIn(5, 120), b.coerceIn(1, 30))
                        showCustomSettingsDialog = false
                    }
                ) {
                    Text("حفظ التخصيص")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomSettingsDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

// FULLSCREEN POMODORO VIEW (Page 4 requirement)
@Composable
fun FullscreenPomodoroView(
    secondsRemaining: Int,
    isRunning: Boolean,
    isFocusPhase: Boolean,
    ambianceColor: Color,
    ambianceOptions: List<Pair<String, Color>>,
    currentAmbianceIndex: Int,
    onSelectAmbiance: (Int) -> Unit,
    onStartPause: () -> Unit,
    onReset: () -> Unit,
    onExitFullscreen: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ambianceColor)
            .padding(24.dp)
    ) {
        // Top row controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.Black.copy(alpha = 0.35f)
            ) {
                Text(
                    text = if (isFocusPhase) "جلسة تركيز كاملة 🧠" else "استراحة استرخاء ☕",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            IconButton(
                onClick = onExitFullscreen,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.35f))
            ) {
                Icon(
                    imageVector = Icons.Default.FullscreenExit,
                    contentDescription = "الخروج من الشاشة الكاملة",
                    tint = Color.White
                )
            }
        }

        // Prominent Fullscreen Countdown Display
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = TimeUtils.formatMinutesSeconds(secondsRemaining),
                fontSize = 92.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 6.sp,
                lineHeight = 96.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (isFocusPhase) "أغلق كل ما يشتتك وركز على درسك الحالي" else "تنفس بعمق، اشرب ماء، واستعد للجولة القادمة",
                fontSize = 16.sp,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center
            )
        }

        // Bottom Controls and Ambiance Selector
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Palette changer row
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "اللون:",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )
                ambianceOptions.forEachIndexed { index, (_, color) ->
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (currentAmbianceIndex == index) 2.dp else 0.dp,
                                color = Color.White,
                                shape = CircleShape
                            )
                            .clickable { onSelectAmbiance(index) }
                    )
                }
            }

            // Big Start/Pause & Reset buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onStartPause,
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF1E293B)
                    )
                ) {
                    Icon(
                        imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = Color(0xFF1E293B)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRunning) "إيقاف مؤقت" else "متابعة الجلسة",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onReset,
                    modifier = Modifier
                        .size(60.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black.copy(alpha = 0.35f),
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay,
                        contentDescription = "إعادة ضبط",
                        tint = Color.White
                    )
                }
            }
        }
    }
}
