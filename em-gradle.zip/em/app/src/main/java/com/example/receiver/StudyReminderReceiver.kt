package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.LessonEntity
import com.example.utils.NotificationHelper
import com.example.utils.StudyReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class StudyReminderReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_STUDY_REMINDER = "com.example.ACTION_STUDY_REMINDER"
        const val EXTRA_LESSON_ID = "extra_lesson_id"
        const val EXTRA_LESSON_TITLE = "extra_lesson_title"
        const val EXTRA_LESSON_SUBJECT = "extra_lesson_subject"
        const val EXTRA_LESSON_START_TIME = "extra_lesson_start_time"
        const val EXTRA_LESSON_LOCATION = "extra_lesson_location"
        const val EXTRA_LESSON_DAY_OF_WEEK = "extra_lesson_day_of_week"
        const val EXTRA_REMINDER_MINUTES = "extra_reminder_minutes"
        private const val TAG = "StudyReminderReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return

        when (intent.action) {
            ACTION_STUDY_REMINDER -> {
                val lessonId = intent.getLongExtra(EXTRA_LESSON_ID, 0L)
                val title = intent.getStringExtra(EXTRA_LESSON_TITLE) ?: "جلسة مذاكرة"
                val subject = intent.getStringExtra(EXTRA_LESSON_SUBJECT) ?: "عام"
                val startTime = intent.getStringExtra(EXTRA_LESSON_START_TIME) ?: "09:00"
                val location = intent.getStringExtra(EXTRA_LESSON_LOCATION) ?: ""
                val dayOfWeek = intent.getIntExtra(EXTRA_LESSON_DAY_OF_WEEK, 1)
                val minutesBefore = intent.getIntExtra(EXTRA_REMINDER_MINUTES, 15)

                Log.d(TAG, "Triggering study reminder for: $title ($subject) at $startTime")

                // 1. Show the gentle push reminder notification
                NotificationHelper.showGentleStudyReminder(
                    context = context,
                    lessonTitle = title,
                    subject = subject,
                    startTime = startTime,
                    location = location,
                    minutesBefore = minutesBefore,
                    notificationId = (lessonId % 100000).toInt().coerceAtLeast(1001)
                )

                // 2. Automatically reschedule for next week's occurrence
                val lesson = LessonEntity(
                    id = lessonId,
                    title = title,
                    subject = subject,
                    dayOfWeek = dayOfWeek,
                    startTime = startTime,
                    endTime = startTime,
                    locationOrRoom = location,
                    reminderMinutesBefore = minutesBefore,
                    isEnabled = true
                )
                StudyReminderScheduler.scheduleLessonReminder(context, lesson)
            }

            Intent.ACTION_BOOT_COMPLETED -> {
                Log.d(TAG, "Device reboot completed, rescheduling all study reminders from database")
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val db = AppDatabase.getDatabase(context)
                        val lessons = db.lessonDao().getAllLessons().firstOrNull() ?: emptyList()
                        StudyReminderScheduler.rescheduleAllLessons(context, lessons)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    } finally {
                        pendingResult.finish()
                    }
                }
            }
        }
    }
}
